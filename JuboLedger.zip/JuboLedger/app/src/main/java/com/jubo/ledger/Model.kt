package com.jubo.ledger

import java.time.DayOfWeek
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.temporal.ChronoUnit
import java.util.Locale

/* ──────────────────────────────────────────────────────────────
 * 보스 / 결정석 가격 (단위: 만 메소, 2026년 6월 기준 정리표)
 * 패치로 시세가 바뀌면 이 표만 고치면 됩니다.
 * ────────────────────────────────────────────────────────────── */

data class Tier(val name: String, val price: Long)

data class Boss(
    val id: String,
    val name: String,
    val tiers: List<Tier>,
    val monthly: Boolean = false,
    /** 최대 입장 인원. 메이플 파티 상한이 6명이라 기본값은 6입니다. */
    val maxParty: Int = 6
)

/**
 * 보스 목록 — 이름과 순서는 인게임 스케줄러 API(`content_name`, `list_order_no`)를 그대로 따릅니다.
 * 이름이 API와 한 글자라도 다르면 스케줄러 동기화에서 매칭되지 않습니다.
 *
 * 가격 단위는 만 메소 (2026년 7월 1일 기준, 나무위키 「강렬한 힘의 결정」).
 * 0 은 "가격 아직 모름" 이라는 뜻이며 수익 합산에서 제외됩니다.
 */
object Bosses {

    val weekly: List<Boss> = listOf(
        Boss("zk", "자쿰", listOf(Tier("카오스", 808))),
        Boss("mg", "매그너스", listOf(Tier("하드", 856))),
        Boss("pp", "파풀라투스", listOf(Tier("카오스", 1310))),
        Boss("pr", "피에르", listOf(Tier("카오스", 817))),
        Boss("bb", "반반", listOf(Tier("카오스", 815))),
        Boss("bq", "블러디퀸", listOf(Tier("카오스", 814))),
        Boss("vl", "벨룸", listOf(Tier("카오스", 928))),
        Boss("su", "스우", listOf(Tier("노멀", 1670), Tier("하드", 5150), Tier("익스트림", 57400))),
        Boss("dm", "데미안", listOf(Tier("노멀", 1750), Tier("하드", 4890))),
        Boss("slm", "가디언 엔젤 슬라임", listOf(Tier("노멀", 2550), Tier("카오스", 7510))),
        Boss("lu", "루시드", listOf(Tier("이지", 2980), Tier("노멀", 3560), Tier("하드", 6290))),
        Boss("wl", "윌", listOf(Tier("이지", 3230), Tier("노멀", 4110), Tier("하드", 7710))),
        Boss("dk", "더스크", listOf(Tier("노멀", 4400), Tier("카오스", 6980))),
        Boss("jh", "진 힐라", listOf(Tier("노멀", 7120), Tier("하드", 10600))),
        Boss("du", "듄켈", listOf(Tier("노멀", 4750), Tier("하드", 9444))),
        Boss("sr", "선택받은 세렌", listOf(Tier("노멀", 23900), Tier("하드", 35600), Tier("익스트림", 283500))),
        Boss("kl", "감시자 칼로스", listOf(Tier("이지", 28000), Tier("노멀", 50500), Tier("카오스", 127300), Tier("익스트림", 410400))),
        Boss("kr", "카링", listOf(Tier("이지", 37700), Tier("노멀", 67800), Tier("하드", 173900), Tier("익스트림", 538700))),
        Boss("lb", "림보", listOf(Tier("노멀", 102600), Tier("하드", 238500))),
        Boss("bd", "발드릭스", listOf(Tier("노멀", 136800), Tier("하드", 307800))),
        Boss("ad", "최초의 대적자", listOf(Tier("이지", 30800), Tier("노멀", 56000), Tier("하드", 143500), Tier("익스트림", 471200))),
        Boss("hs", "찬란한 흉성", listOf(Tier("노멀", 62500), Tier("하드", 267800))),
        Boss("jp", "유피테르", listOf(Tier("노멀", 161500), Tier("하드", 484500))),
        Boss("ml", "시즌 보스 메이린", listOf(Tier("노멀", 0), Tier("하드", 0))),
        Boss("bl", "벨로나", listOf(Tier("이지", 44000), Tier("노멀", 85000), Tier("하드", 295000)))
    )

    val monthly: List<Boss> = listOf(
        Boss("bm", "검은 마법사", listOf(Tier("하드", 66500), Tier("익스트림", 874000)), monthly = true)
    )

    val all: List<Boss> = weekly + monthly
    val byId: Map<String, Boss> = all.associateBy { it.id }
    val byName: Map<String, Boss> = all.associateBy { it.name }

    fun price(bossId: String, tier: String): Long =
        byId[bossId]?.tiers?.firstOrNull { it.name == tier }?.price ?: 0L

    /** 캐릭터당 주간 보스 결정석 획득 한도 */
    const val CAP_CHARACTER = 12

    /** 계정당 주간 결정석 판매 한도 */
    const val CAP_ACCOUNT = 90
}

/** 사용자가 앱에서 고친 가격이 있으면 그것을, 없으면 기본 표를 씁니다. */
fun priceOf(bossId: String, tier: String, overrides: Map<String, Long>): Long =
    overrides[priceKey(bossId, tier)] ?: Bosses.price(bossId, tier)

fun priceKey(bossId: String, tier: String): String = "$bossId:$tier"

/** 파티로 잡으면 결정석 값이 인원수만큼 정확히 나뉘고, 소수점은 버립니다. */
fun sharePrice(base: Long, party: Int): Long =
    if (party <= 1) base else base / party.toLong()

/** 가격을 모르는 보스는 "?" 로 표시하고 합산에서 뺍니다. */
fun priceText(man: Long): String = if (man <= 0L) "가격 ?" else meso(man)

/* ──────────────────────────────────────────────────────────────
 * 초기화 시각 — 전부 한국 시간(KST) 기준
 *   주간보스        : 매주 목요일 오전 0시
 *   플래그 / 수로   : 매주 목요일 오전 0시 (길드 콘텐츠, 계정당 1회)
 *   검은 마법사     : 매월 1일 오전 0시
 * ────────────────────────────────────────────────────────────── */

object Dates {
    val KST: ZoneId = ZoneId.of("Asia/Seoul")

    fun today(): java.time.LocalDate = java.time.LocalDate.now(KST)
    fun key(d: java.time.LocalDate): String = d.toString()
    fun todayKey(): String = key(today())
    fun parse(k: String): java.time.LocalDate? = try { java.time.LocalDate.parse(k) } catch (e: Exception) { null }

    /** 보스 주는 목요일에 시작합니다 */
    fun weekStart(d: java.time.LocalDate): java.time.LocalDate =
        d.minusDays((((d.dayOfWeek.value - DayOfWeek.THURSDAY.value) % 7 + 7) % 7).toLong())

    fun label(d: java.time.LocalDate): String =
        d.monthValue.toString() + "월 " + d.dayOfMonth.toString() + "일"
}

object Reset {

    private val KST: ZoneId = ZoneId.of("Asia/Seoul")
    private const val WEEK_MS = 7L * 24L * 60L * 60L * 1000L

    private fun todayKst(): ZonedDateTime =
        ZonedDateTime.now(KST).truncatedTo(ChronoUnit.DAYS)

    fun lastWeekly(day: DayOfWeek): Long {
        val today = todayKst()
        val back = ((today.dayOfWeek.value - day.value) % 7 + 7) % 7
        return today.minusDays(back.toLong()).toInstant().toEpochMilli()
    }

    fun nextWeekly(day: DayOfWeek): Long = lastWeekly(day) + WEEK_MS

    fun lastMonthly(): Long =
        todayKst().withDayOfMonth(1).toInstant().toEpochMilli()

    fun nextMonthly(): Long =
        todayKst().withDayOfMonth(1).plusMonths(1).toInstant().toEpochMilli()

    val BOSS_DAY: DayOfWeek = DayOfWeek.THURSDAY

    /** 플래그 레이스·지하 수로도 주간보스와 같은 목요일 0시 초기화 */
    val GUILD_DAY: DayOfWeek = DayOfWeek.THURSDAY

    /** "3일 12:04" 또는 "07:21:35" */
    fun countdown(untilMs: Long, nowMs: Long = System.currentTimeMillis()): String {
        var s = (untilMs - nowMs) / 1000L
        if (s < 0) s = 0
        val d = s / 86400
        val h = (s % 86400) / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        return if (d > 0) String.format(Locale.KOREA, "%d일 %02d:%02d", d, h, m)
        else String.format(Locale.KOREA, "%02d:%02d:%02d", h, m, sec)
    }
}

/* ──────────────────────────────────────────────────────────────
 * 메소 표기 — 조 / 억 / 만
 * ────────────────────────────────────────────────────────────── */

fun meso(man: Long): String {
    if (man <= 0L) return "0"
    var v = man
    val parts = ArrayList<String>(3)
    val jo = v / 100_000_000L
    v %= 100_000_000L
    val eok = v / 10_000L
    v %= 10_000L
    if (jo > 0L) parts.add(group(jo) + "조")
    if (eok > 0L) parts.add(group(eok) + "억")
    if (v > 0L || parts.isEmpty()) parts.add(group(v) + "만")
    return parts.take(2).joinToString(" ")
}

private fun group(n: Long): String = String.format(Locale.KOREA, "%,d", n)

/* ──────────────────────────────────────────────────────────────
 * 앱 상태
 * ────────────────────────────────────────────────────────────── */

data class Toon(
    val id: String,
    val name: String,
    val ocid: String = "",
    val world: String = "",
    val job: String = "",
    val level: Int = 0,
    val bosses: Map<String, String> = emptyMap(),
    val done: Set<String> = emptySet(),
    /** 보스별 파티 인원. 없으면 1인(솔격) */
    val party: Map<String, Int> = emptyMap(),
    /** 인게임 스케줄러와 마지막으로 맞춘 시각 (0 = 한 번도 안 함) */
    val syncedAt: Long = 0L
)

/** 보스 하나를 잡았다는 기록 한 줄 */
data class ClearEntry(
    /** yyyy-MM-dd (한국 시간) */
    val date: String,
    val toonId: String,
    val toonName: String,
    val bossId: String,
    val tier: String,
    val party: Int,
    /** 내 몫 (만 메소) */
    val meso: Long
)

data class AppState(
    val toons: List<Toon> = emptyList(),
    val apiKey: String = "",
    /** 플래그 레이스 · 지하 수로는 길드(계정) 단위라 캐릭터가 아니라 여기에 둡니다 */
    val guildFlag: Boolean = false,
    val guildWater: Boolean = false,
    /** 앱을 열 때 인게임 스케줄러를 자동으로 한 번 읽어올지 */
    val autoSync: Boolean = true,
    /** 마지막 동기화 때 API가 알려준 기준 시각 (응답의 date) */
    val lastApiDate: String = "",
    /** 사용자가 고친 결정석 가격. "보스id:난이도" → 만 메소 */
    val priceOverrides: Map<String, Long> = emptyMap(),
    /** 날짜별 클리어 기록 — 오래된 것부터 */
    val log: List<ClearEntry> = emptyList(),
    val rBoss: Long = 0L,
    val rGuild: Long = 0L,
    val rMonth: Long = 0L,
    /** 수요일 저녁 — 아직 남은 숙제 알림 */
    val notifyDeadline: Boolean = false,
    val deadlineHour: Int = 21,
    val deadlineMin: Int = 0,
    /** 목요일 아침 — 지난주 결산 알림 */
    val notifyWeekly: Boolean = false,
    val weeklyHour: Int = 9,
    val weeklyMin: Int = 0
)

/**
 * 주간과 월간을 나눠서 셉니다.
 * 검은 마법사는 한 달에 한 번이라 주간 목표에 섞이면 목표가 부풀려집니다.
 */
data class Stat(
    val earned: Long,
    val target: Long,
    val done: Int,
    val total: Int,
    val weeklyEarned: Long = 0L,
    val weeklyTarget: Long = 0L,
    val weeklyDone: Int = 0,
    val weeklyTotal: Int = 0,
    val monthlyEarned: Long = 0L,
    val monthlyTarget: Long = 0L,
    val monthlyDone: Int = 0,
    val monthlyTotal: Int = 0
)

/** 이 캐릭터가 그 보스를 몇 명이서 잡는지 (없으면 1인) */
fun Toon.partyOf(bossId: String): Int = (party[bossId] ?: 1).coerceAtLeast(1)

/** 파티 분배까지 반영한 내 몫 */
fun Toon.myShare(bossId: String, tier: String, overrides: Map<String, Long>): Long =
    sharePrice(priceOf(bossId, tier, overrides), partyOf(bossId))

fun Toon.stat(overrides: Map<String, Long> = emptyMap()): Stat {
    var wEarned = 0L; var wTarget = 0L; var wDone = 0; var wTotal = 0
    var mEarned = 0L; var mTarget = 0L; var mDone = 0; var mTotal = 0

    for ((bossId, tier) in bosses) {
        val boss = Bosses.byId[bossId] ?: continue
        val share = myShare(bossId, tier, overrides)
        val cleared = done.contains(bossId)
        if (boss.monthly) {
            mTarget += share; mTotal++
            if (cleared) { mEarned += share; mDone++ }
        } else {
            wTarget += share; wTotal++
            if (cleared) { wEarned += share; wDone++ }
        }
    }

    return Stat(
        earned = wEarned + mEarned,
        target = wTarget + mTarget,
        done = wDone + mDone,
        total = wTotal + mTotal,
        weeklyEarned = wEarned, weeklyTarget = wTarget, weeklyDone = wDone, weeklyTotal = wTotal,
        monthlyEarned = mEarned, monthlyTarget = mTarget, monthlyDone = mDone, monthlyTotal = mTotal
    )
}

/** 길드 콘텐츠를 대표로 표시할 캐릭터 — 레벨이 가장 높은 캐릭터 */
fun List<Toon>.guildRep(): Toon? = maxByOrNull { it.level }

fun List<Toon>.totals(overrides: Map<String, Long> = emptyMap()): Stat {
    var e = 0L; var t = 0L; var d = 0; var n = 0
    var we = 0L; var wt = 0L; var wd = 0; var wn = 0
    var me = 0L; var mt = 0L; var md = 0; var mn = 0
    forEach {
        val s = it.stat(overrides)
        e += s.earned; t += s.target; d += s.done; n += s.total
        we += s.weeklyEarned; wt += s.weeklyTarget; wd += s.weeklyDone; wn += s.weeklyTotal
        me += s.monthlyEarned; mt += s.monthlyTarget; md += s.monthlyDone; mn += s.monthlyTotal
    }
    return Stat(e, t, d, n, we, wt, wd, wn, me, mt, md, mn)
}


/* ──────────────────────────────────────────────────────────────
 * 기록 집계
 * ────────────────────────────────────────────────────────────── */

/** 날짜별 합계 (만 메소) */
fun List<ClearEntry>.byDate(): Map<String, Long> {
    val m = LinkedHashMap<String, Long>()
    forEach { m[it.date] = (m[it.date] ?: 0L) + it.meso }
    return m
}

/** [from, to) 구간 합계 */
fun List<ClearEntry>.sumBetween(from: java.time.LocalDate, toExclusive: java.time.LocalDate): Long {
    var total = 0L
    forEach {
        val d = Dates.parse(it.date) ?: return@forEach
        if (!d.isBefore(from) && d.isBefore(toExclusive)) total += it.meso
    }
    return total
}

fun List<ClearEntry>.onDate(key: String): List<ClearEntry> = filter { it.date == key }
