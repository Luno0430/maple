package com.jubo.ledger

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.LocalDate
import java.util.Locale

class MainActivity : ComponentActivity() {

    /** 앱 화면으로 돌아올 때마다 1씩 올라갑니다 — 이때 스케줄러를 다시 읽습니다 */
    private val resumeTick = mutableStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val store = Store(applicationContext)
        setContent {
            JuboTheme {
                App(store, resumeTick.value)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        resumeTick.value = resumeTick.value + 1
    }
}

private enum class Tab { Today, History, More }

private sealed interface Route {
    data object Tabs : Route
    data class Picker(val toonId: String) : Route
    data object Import : Route
    data object ApiTool : Route
    data object Matrix : Route
    data object Prices : Route
}

/* ══════════════════════════════════════════════════════════════
 * 루트
 * ══════════════════════════════════════════════════════════════ */

@Composable
private fun App(store: Store, resumeTick: Int) {
    val p = LocalPalette.current
    val scope = rememberCoroutineScope()

    var route by remember { mutableStateOf<Route>(Route.Tabs) }
    var tab by remember { mutableStateOf(Tab.Today) }
    var selected by remember { mutableStateOf(0) }
    var now by remember { mutableStateOf(System.currentTimeMillis()) }
    var syncing by remember { mutableStateOf(false) }
    var syncMsg by remember { mutableStateOf<String?>(null) }
    var lastAutoSync by remember { mutableStateOf(0L) }

    LaunchedEffect(Unit) {
        while (true) {
            delay(1000)
            now = System.currentTimeMillis()
            store.refreshResets()
        }
    }

    // 앱을 열 때, 그리고 게임 등에 갔다 돌아올 때마다 (1분 안에 했으면 건너뜀)
    LaunchedEffect(resumeTick) {
        val s = store.state
        val t = System.currentTimeMillis()
        if (resumeTick > 0 && s.autoSync && !syncing &&
            s.apiKey.isNotBlank() && s.toons.isNotEmpty() && t - lastAutoSync > 60_000L
        ) {
            lastAutoSync = t
            syncing = true
            syncMsg = summarizeSync(syncAll(store) { syncMsg = it })
            syncing = false
        }
    }

    val doSync: () -> Unit = {
        if (!syncing) {
            when {
                store.state.apiKey.isBlank() -> syncMsg = "먼저 API 키를 넣어 주세요. (더보기 → 캐릭터 불러오기)"
                store.state.toons.isEmpty() -> syncMsg = "먼저 캐릭터를 불러와 주세요."
                else -> scope.launch {
                    syncing = true
                    syncMsg = summarizeSync(syncAll(store) { syncMsg = it })
                    syncing = false
                }
            }
        }
    }

    val state = store.state
    // -1 이면 아무 캐릭터도 안 펼친 상태
    val sel = if (state.toons.isEmpty() || selected >= state.toons.size) -1 else selected

    Column(
        Modifier
            .fillMaxSize()
            .background(p.ground)
            .safeDrawingPadding()
    ) {
        Box(Modifier.weight(1f)) {
            when (val r = route) {
                is Route.Tabs -> when (tab) {
                    Tab.Today -> TodayTab(
                        store = store, sel = sel, now = now,
                        syncing = syncing, syncMsg = syncMsg,
                        // 같은 캐릭터를 다시 누르면 목록을 접습니다
                        onSelect = { selected = if (selected == it) -1 else it },
                        onEdit = { route = Route.Picker(it) },
                        onSync = doSync
                    )
                    Tab.History -> HistoryTab(store)
                    Tab.More -> MoreTab(
                        store = store,
                        onImport = { route = Route.Import },
                        onMatrix = { route = Route.Matrix },
                        onPrices = { route = Route.Prices },
                        onApiTool = { route = Route.ApiTool }
                    )
                }

                is Route.Picker -> {
                    BackHandler { route = Route.Tabs }
                    PickerScreen(store, r.toonId) { route = Route.Tabs }
                }

                is Route.Import -> {
                    BackHandler { route = Route.Tabs }
                    ImportScreen(store, { route = Route.ApiTool }) { route = Route.Tabs }
                }

                is Route.ApiTool -> {
                    BackHandler { route = Route.Import }
                    ApiToolScreen(store) { route = Route.Import }
                }

                is Route.Matrix -> {
                    BackHandler { route = Route.Tabs }
                    MatrixScreen(store) { route = Route.Tabs }
                }

                is Route.Prices -> {
                    BackHandler { route = Route.Tabs }
                    PriceScreen(store) { route = Route.Tabs }
                }
            }
        }

        if (route is Route.Tabs) {
            BottomBar(tab) { tab = it }
        }
    }
}

@Composable
private fun BottomBar(current: Tab, onTab: (Tab) -> Unit) {
    val p = LocalPalette.current
    Column {
        Box(Modifier.fillMaxWidth().height(1.dp).background(p.lineSoft))
        Row(
            Modifier
                .fillMaxWidth()
                .background(p.panel)
                .padding(vertical = 6.dp)
        ) {
            BarTab("오늘", "체크", current == Tab.Today, Modifier.weight(1f)) { onTab(Tab.Today) }
            BarTab("기록", "달력", current == Tab.History, Modifier.weight(1f)) { onTab(Tab.History) }
            BarTab("더보기", "설정", current == Tab.More, Modifier.weight(1f)) { onTab(Tab.More) }
        }
    }
}

@Composable
private fun BarTab(label: String, sub: String, on: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val p = LocalPalette.current
    Column(
        modifier.clickable(onClick = onClick).padding(vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            Modifier
                .width(26.dp)
                .height(3.dp)
                .background(if (on) p.accent else Color.Transparent, RoundedCornerShape(2.dp))
        )
        Spacer(Modifier.height(6.dp))
        Text(label, color = if (on) p.text else p.muted, fontSize = 13.sp, fontWeight = if (on) FontWeight.Bold else FontWeight.Normal)
        Text(sub, color = if (on) p.accent else p.muted.copy(alpha = 0.7f), fontSize = 9.5.sp)
    }
}

/* ══════════════════════════════════════════════════════════════
 * 공용 조각
 * ══════════════════════════════════════════════════════════════ */

@Composable
private fun Card(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val p = LocalPalette.current
    Column(
        modifier
            .fillMaxWidth()
            .background(p.panel, RoundedCornerShape(16.dp))
            .border(1.dp, p.lineSoft, RoundedCornerShape(16.dp)),
        content = content
    )
}

@Composable
private fun SectionTitle(title: String, hint: String? = null, action: String? = null, onAction: (() -> Unit)? = null) {
    val p = LocalPalette.current
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = p.text, fontSize = 15.sp, fontWeight = FontWeight.Bold)
        if (hint != null) {
            Spacer(Modifier.width(8.dp))
            Text(hint, color = p.muted, fontSize = 11.5.sp)
        }
        Spacer(Modifier.weight(1f))
        if (action != null && onAction != null) {
            Text(
                action, color = p.accent, fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.clickable { onAction() }.padding(4.dp)
            )
        }
    }
}

@Composable
private fun Bar(fraction: Float, height: Dp, color: Color, track: Color) {
    Box(
        Modifier.fillMaxWidth().height(height).background(track, RoundedCornerShape(99.dp))
    ) {
        Box(
            Modifier
                .fillMaxWidth(fraction.coerceIn(0f, 1f))
                .fillMaxHeight()
                .background(color, RoundedCornerShape(99.dp))
        )
    }
}

@Composable
private fun CheckMark(checked: Boolean) {
    val p = LocalPalette.current
    Box(
        Modifier
            .size(21.dp)
            .background(if (checked) p.accent else Color.Transparent, RoundedCornerShape(7.dp))
            .border(1.5.dp, if (checked) p.accent else p.line, RoundedCornerShape(7.dp)),
        contentAlignment = Alignment.Center
    ) {
        if (checked) Text("✓", color = p.checkInk, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}

/** 난이도 배지 — 채운 알약 */
@Composable
private fun TierPill(tier: String) {
    val p = LocalPalette.current
    val c = p.tier(tier)
    Text(
        tier,
        color = c,
        fontSize = 10.5.sp,
        fontWeight = FontWeight.Bold,
        modifier = Modifier
            .background(c.copy(alpha = 0.16f), RoundedCornerShape(6.dp))
            .padding(horizontal = 7.dp, vertical = 2.dp)
    )
}

/** 파티 인원 배지 — 누르면 인원 고르는 창이 뜹니다 */
@Composable
private fun PartyPill(party: Int, onClick: () -> Unit) {
    val p = LocalPalette.current
    val solo = party <= 1
    val c = if (solo) p.muted else p.normal
    Text(
        if (solo) "솔로" else party.toString() + "인",
        color = c,
        fontSize = 10.5.sp,
        fontWeight = if (solo) FontWeight.Medium else FontWeight.Bold,
        modifier = Modifier
            .background(if (solo) Color.Transparent else c.copy(alpha = 0.16f), RoundedCornerShape(6.dp))
            .border(1.dp, if (solo) p.line else Color.Transparent, RoundedCornerShape(6.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 7.dp, vertical = 2.dp)
    )
}

@Composable
private fun ActionButton(
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    filled: Boolean = false,
    tone: Color? = null
) {
    val p = LocalPalette.current
    val c = tone ?: p.accent
    Text(
        label,
        color = if (filled) p.checkInk else c,
        fontSize = 13.sp,
        fontWeight = FontWeight.Bold,
        textAlign = TextAlign.Center,
        modifier = modifier
            .background(if (filled) c else Color.Transparent, RoundedCornerShape(11.dp))
            .border(1.dp, if (filled) Color.Transparent else c.copy(alpha = 0.55f), RoundedCornerShape(11.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 10.dp)
    )
}

@Composable
private fun TopBar(title: String, sub: String? = null, onBack: () -> Unit, trailing: @Composable () -> Unit = {}) {
    val p = LocalPalette.current
    Column {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(
                "‹", color = p.text2, fontSize = 22.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.clickable { onBack() }.padding(end = 12.dp)
            )
            Column(Modifier.weight(1f)) {
                Text(title, color = p.text, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                if (sub != null) Text(sub, color = p.muted, fontSize = 11.sp)
            }
            trailing()
        }
        Box(Modifier.fillMaxWidth().height(1.dp).background(p.lineSoft))
    }
}

@Composable
private fun SubHead(left: String, right: String) {
    val p = LocalPalette.current
    Row(
        Modifier.fillMaxWidth().background(p.panel2).padding(horizontal = 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(left, color = p.text2, fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.weight(1f))
        Text(right, color = p.muted, fontSize = 11.sp)
    }
}

/** "5.1억" 처럼 짧게 */
private fun mesoShort(man: Long): String {
    if (man <= 0L) return ""
    val eok = man / 10000.0
    return if (eok >= 1.0) String.format(Locale.KOREA, "%.1f억", eok)
    else String.format(Locale.KOREA, "%d만", man)
}

/* ══════════════════════════════════════════════════════════════
 * 오늘 탭
 * ══════════════════════════════════════════════════════════════ */

@Composable
private fun TodayTab(
    store: Store,
    sel: Int,
    now: Long,
    syncing: Boolean,
    syncMsg: String?,
    onSelect: (Int) -> Unit,
    onEdit: (String) -> Unit,
    onSync: () -> Unit
) {
    val p = LocalPalette.current
    val state = store.state

    Column(Modifier.fillMaxSize()) {
        // 헤더
        Row(
            Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("🍁", fontSize = 17.sp)
            Spacer(Modifier.width(7.dp))
            Text("주간 ", color = p.text, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text("메이플", color = p.accent, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            Text(
                if (syncing) "새로고침 중" else "새로고침",
                color = if (syncing) p.muted else p.accent,
                fontSize = 12.5.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.clickable { onSync() }.padding(6.dp)
            )
        }

        Column(
            Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(start = 16.dp, end = 16.dp, bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            if (state.toons.isEmpty()) {
                WeekCard(state, now)
            } else {
                // 위젯처럼 좌우로 넘겨서 요약 ↔ 비중 그래프 전환
                val pagerState = rememberPagerState(pageCount = { 2 })
                val scope = rememberCoroutineScope()
                val shown = minOf(state.toons.size, 8) + (if (state.toons.size > 8) 1 else 0)
                // 요약 카드가 화면을 다 먹지 않게 상한을 둡니다. 넘치면 비중 카드 안에서 스크롤됩니다.
                val pageHeight = maxOf(360, minOf(470, 200 + shown * 46)).dp

                HorizontalPager(
                    state = pagerState,
                    modifier = Modifier.fillMaxWidth().height(pageHeight),
                    pageSpacing = 12.dp
                ) { page ->
                    if (page == 0) WeekCard(state, now, Modifier.fillMaxHeight())
                    else ShareCard(state, Modifier.fillMaxHeight())
                }

                Spacer(Modifier.height(2.dp))
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    listOf("요약", "비중").forEachIndexed { i, label ->
                        val on = pagerState.currentPage == i
                        Text(
                            label,
                            color = if (on) p.accent else p.muted,
                            fontSize = 11.sp,
                            fontWeight = if (on) FontWeight.Bold else FontWeight.Normal,
                            modifier = Modifier
                                .clickable { scope.launch { pagerState.animateScrollToPage(i) } }
                                .background(
                                    if (on) p.accentWash else Color.Transparent,
                                    RoundedCornerShape(99.dp)
                                )
                                .padding(horizontal = 11.dp, vertical = 5.dp)
                        )
                        if (i == 0) Spacer(Modifier.width(6.dp))
                    }
                }
            }

            if (syncMsg != null) {
                Text(syncMsg, color = p.muted, fontSize = 11.5.sp, lineHeight = 17.sp)
            }

            if (state.toons.isEmpty()) {
                Card {
                    Column(
                        Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 30.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("아직 캐릭터가 없어요", color = p.text, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(7.dp))
                        Text(
                            "더보기 탭에서 넥슨 API 키를 넣으면\n계정의 캐릭터를 한 번에 불러옵니다.",
                            color = p.muted, fontSize = 12.5.sp, textAlign = TextAlign.Center, lineHeight = 19.sp
                        )
                    }
                }
            } else {
                CharRail(store, state.toons, sel, onSelect)
                if (sel >= 0) {
                    ToonCard(store, state.toons[sel], onEdit) { onSelect(sel) }
                } else {
                    Card {
                        Row(
                            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 18.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                "캐릭터를 누르면 보스 목록이 열립니다",
                                color = p.muted, fontSize = 12.5.sp, modifier = Modifier.weight(1f)
                            )
                            Text("▾", color = p.muted, fontSize = 14.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun WeekCard(state: AppState, now: Long, modifier: Modifier = Modifier) {
    val p = LocalPalette.current
    val t = state.toons.totals(state.priceOverrides)
    val frac = if (t.weeklyTotal > 0) t.weeklyDone.toFloat() / t.weeklyTotal else 0f
    val guild = (if (state.guildFlag) 1 else 0) + (if (state.guildWater) 1 else 0)

    Card(modifier) {
        Column(Modifier.fillMaxHeight().padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("이번 주 획득", color = p.muted, fontSize = 12.sp)
                Spacer(Modifier.weight(1f))
                Text(
                    t.weeklyDone.toString() + " / " + t.weeklyTotal.toString(),
                    color = p.accent, fontSize = 15.sp, fontWeight = FontWeight.Bold
                )
            }
            Spacer(Modifier.height(6.dp))
            Row(verticalAlignment = Alignment.Bottom) {
                Text(meso(t.weeklyEarned), color = p.text, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.width(6.dp))
                Text("메소", color = p.muted, fontSize = 13.sp, modifier = Modifier.padding(bottom = 4.dp))
            }
            Spacer(Modifier.height(12.dp))
            Bar(frac, 8.dp, p.accent, p.panel3)
            Spacer(Modifier.height(9.dp))
            Text(
                "주간 목표 " + meso(t.weeklyTarget) + " · 남은 물량 " + meso(t.weeklyTarget - t.weeklyEarned),
                color = p.text2, fontSize = 12.sp
            )

            // 월간(검은 마법사)은 한 달에 한 번이라 주간 목표와 섞지 않고 따로 셉니다
            if (t.monthlyTotal > 0) {
                Spacer(Modifier.height(14.dp))
                Box(Modifier.fillMaxWidth().height(1.dp).background(p.lineSoft))
                Spacer(Modifier.height(12.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("월간 · 검은 마법사", color = p.muted, fontSize = 11.5.sp)
                    Spacer(Modifier.weight(1f))
                    Text(
                        t.monthlyDone.toString() + " / " + t.monthlyTotal.toString(),
                        color = p.hard, fontSize = 12.sp, fontWeight = FontWeight.Bold
                    )
                }
                Spacer(Modifier.height(7.dp))
                Bar(
                    if (t.monthlyTotal > 0) t.monthlyDone.toFloat() / t.monthlyTotal else 0f,
                    6.dp, p.hard, p.panel3
                )
                Spacer(Modifier.height(7.dp))
                Text(
                    meso(t.monthlyEarned) + " / 목표 " + meso(t.monthlyTarget),
                    color = p.text2, fontSize = 11.5.sp
                )
            }

            Spacer(Modifier.weight(1f))
            Spacer(Modifier.height(14.dp))
            Box(Modifier.fillMaxWidth().height(1.dp).background(p.lineSoft))
            Spacer(Modifier.height(12.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MiniStat("주간 초기화", Reset.countdown(Reset.nextWeekly(Reset.BOSS_DAY), now), p.accent, Modifier.weight(1f))
                MiniStat("월간 (검마)", Reset.countdown(Reset.nextMonthly(), now), p.hard, Modifier.weight(1f))
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MiniStat(
                    "결정석 " + t.done.toString() + "/" + Bosses.CAP_ACCOUNT.toString(),
                    if (t.done > Bosses.CAP_ACCOUNT) "한도 초과" else "계정 한도",
                    if (t.done > Bosses.CAP_ACCOUNT) p.extreme else p.muted,
                    Modifier.weight(1f)
                )
                MiniStat("길드 " + guild.toString() + "/2", "플래그 · 수로", p.normal, Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun MiniStat(label: String, value: String, tone: Color, modifier: Modifier) {
    val p = LocalPalette.current
    Column(
        modifier
            .background(p.panel2, RoundedCornerShape(11.dp))
            .padding(horizontal = 11.dp, vertical = 9.dp)
    ) {
        Text(label, color = p.muted, fontSize = 10.5.sp, maxLines = 1)
        Spacer(Modifier.height(3.dp))
        Text(value, color = tone, fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 1)
    }
}

@Composable
private fun CharRail(store: Store, toons: List<Toon>, sel: Int, onSelect: (Int) -> Unit) {
    val p = LocalPalette.current
    Column {
        SectionTitle("본부캐", toons.size.toString() + "명")
        Spacer(Modifier.height(9.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(toons.size) { i ->
                val t = toons[i]
                val s = t.stat(store.state.priceOverrides)
                val on = i == sel
                Column(
                    Modifier
                        .widthIn(min = 116.dp)
                        .background(if (on) p.accentWash else p.panel, RoundedCornerShape(13.dp))
                        .border(if (on) 1.5.dp else 1.dp, if (on) p.accent else p.lineSoft, RoundedCornerShape(13.dp))
                        .clickable { onSelect(i) }
                        .padding(horizontal = 12.dp, vertical = 10.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            t.name, color = p.text, fontSize = 13.sp, fontWeight = FontWeight.Bold,
                            maxLines = 1, overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.widthIn(max = 104.dp)
                        )
                        if (on) {
                            Spacer(Modifier.width(5.dp))
                            Text("▴", color = p.accent, fontSize = 12.sp)
                        }
                    }
                    Spacer(Modifier.height(4.dp))
                    Text(
                        if (s.earned > 0) mesoShort(s.earned) else s.done.toString() + " / " + s.total.toString(),
                        color = if (on) p.accent else p.muted, fontSize = 11.5.sp, maxLines = 1
                    )
                    Spacer(Modifier.height(7.dp))
                    Bar(if (s.total > 0) s.done.toFloat() / s.total else 0f, 3.dp, if (on) p.accent else p.muted, p.panel3)
                }
            }
        }
    }
}

@Composable
private fun ToonCard(store: Store, toon: Toon, onEdit: (String) -> Unit, onCollapse: () -> Unit = {}) {
    val p = LocalPalette.current
    val s = toon.stat(store.state.priceOverrides)
    val weekly = Bosses.weekly.filter { toon.bosses.containsKey(it.id) }
    val monthly = Bosses.monthly.filter { toon.bosses.containsKey(it.id) }
    val weeklyCount = toon.bosses.keys.count { Bosses.byId[it]?.monthly == false }

    var partyFor by remember { mutableStateOf<String?>(null) }

    Card {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 15.dp, vertical = 13.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f).clickable { onCollapse() }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(toon.name, color = p.text, fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                    Spacer(Modifier.width(6.dp))
                    Text("▴", color = p.muted, fontSize = 12.sp)
                }
                val meta = listOfNotNull(
                    toon.world.takeIf { it.isNotBlank() },
                    toon.job.takeIf { it.isNotBlank() },
                    if (toon.level > 0) "Lv." + toon.level.toString() else null
                ).joinToString(" · ")
                if (meta.isNotBlank()) {
                    Text(meta, color = p.muted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
            Text(
                weeklyCount.toString() + "/" + Bosses.CAP_CHARACTER.toString(),
                color = if (weeklyCount > Bosses.CAP_CHARACTER) p.extreme else p.muted,
                fontSize = 11.5.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .background(p.panel2, RoundedCornerShape(99.dp))
                    .padding(horizontal = 9.dp, vertical = 4.dp)
            )
            Spacer(Modifier.width(8.dp))
            Text(
                "보스 선택", color = p.accent, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.clickable { onEdit(toon.id) }.padding(4.dp)
            )
        }
        Box(Modifier.fillMaxWidth().height(1.dp).background(p.lineSoft))

        if (weekly.isEmpty() && monthly.isEmpty()) {
            Column(
                Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 26.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("아직 도는 보스가 없어요.", color = p.muted, fontSize = 13.sp)
                Spacer(Modifier.height(12.dp))
                ActionButton("보스 선택하기", { onEdit(toon.id) }, filled = true)
            }
        } else {
            if (weekly.isNotEmpty()) {
                SubHead("주간보스", s.done.toString() + " / " + s.total.toString())
                weekly.forEach { b -> BossRow(store, toon, b) { partyFor = b.id } }
            }
            if (monthly.isNotEmpty()) {
                SubHead("월간", "매월 1일 초기화")
                monthly.forEach { b -> BossRow(store, toon, b) { partyFor = b.id } }
            }
        }

        if (store.state.toons.guildRep()?.id == toon.id) {
            SubHead("길드 · 계정당 1회", "목요일 초기화")
            GuildRow("플래그 레이스", store.state.guildFlag) { store.toggleFlag() }
            GuildRow("샤레니안의 지하 수로", store.state.guildWater) { store.toggleWater() }
        }
    }

    val pickBossId = partyFor
    if (pickBossId != null) {
        val boss = Bosses.byId[pickBossId]
        if (boss != null) {
            PartyDialog(
                boss = boss,
                current = toon.partyOf(pickBossId),
                onPick = { n ->
                    store.setParty(toon.id, pickBossId, n)
                    partyFor = null
                },
                onDismiss = { partyFor = null }
            )
        }
    }
}

@Composable
private fun BossRow(store: Store, toon: Toon, boss: Boss, onParty: () -> Unit) {
    val p = LocalPalette.current
    val tier = toon.bosses[boss.id] ?: return
    val party = toon.partyOf(boss.id)
    val price = sharePrice(priceOf(boss.id, tier, store.state.priceOverrides), party)
    val on = toon.done.contains(boss.id)

    Row(
        Modifier
            .fillMaxWidth()
            .background(if (on) p.accent.copy(alpha = 0.14f) else Color.Transparent)
            .padding(vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .width(4.dp)
                .height(34.dp)
                .background(if (on) p.accent else Color.Transparent, RoundedCornerShape(2.dp))
        )
        Row(
            Modifier
                .weight(1f)
                .clickable { store.toggleBoss(toon.id, boss.id) }
                .padding(start = 11.dp, end = 6.dp, top = 10.dp, bottom = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            CheckMark(on)
            Spacer(Modifier.width(11.dp))
            Text(
                boss.name,
                color = if (on) p.text2 else p.text,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                textDecoration = if (on) TextDecoration.LineThrough else null,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f)
            )
            Spacer(Modifier.width(6.dp))
            TierPill(tier)
        }
        PartyPill(party, onParty)
        Spacer(Modifier.width(9.dp))
        Text(
            priceText(price),
            color = if (on) p.gold else p.text2,
            fontSize = 12.5.sp,
            fontWeight = if (on) FontWeight.Bold else FontWeight.Normal,
            maxLines = 1,
            textAlign = TextAlign.End,
            modifier = Modifier.widthIn(min = 74.dp).padding(end = 15.dp)
        )
    }
    Box(Modifier.fillMaxWidth().height(1.dp).background(p.lineSoft))
}

@Composable
private fun GuildRow(label: String, on: Boolean, onToggle: () -> Unit) {
    val p = LocalPalette.current
    Row(
        Modifier
            .fillMaxWidth()
            .background(if (on) p.accent.copy(alpha = 0.14f) else Color.Transparent)
            .clickable(onClick = onToggle)
            .padding(horizontal = 15.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        CheckMark(on)
        Spacer(Modifier.width(11.dp))
        Text(
            label,
            color = if (on) p.text2 else p.text,
            fontSize = 14.sp,
            fontWeight = FontWeight.Medium,
            textDecoration = if (on) TextDecoration.LineThrough else null
        )
    }
}

/** 파티 인원 고르기 */
@Composable
private fun PartyDialog(boss: Boss, current: Int, onPick: (Int) -> Unit, onDismiss: () -> Unit) {
    val p = LocalPalette.current
    Dialog(onDismissRequest = onDismiss) {
        Column(
            Modifier
                .background(p.panel, RoundedCornerShape(18.dp))
                .border(1.dp, p.line, RoundedCornerShape(18.dp))
                .padding(18.dp)
        ) {
            Text(boss.name, color = p.text, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Text(
                "몇 명이서 잡나요? 결정석은 인원수로 나뉩니다.",
                color = p.muted, fontSize = 12.sp
            )
            Spacer(Modifier.height(14.dp))

            (1..boss.maxParty).forEach { n ->
                val on = n == current
                val base = boss.tiers.firstOrNull()?.price ?: 0L
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.dp)
                        .background(if (on) p.accentWash else p.panel2, RoundedCornerShape(11.dp))
                        .border(1.dp, if (on) p.accent else Color.Transparent, RoundedCornerShape(11.dp))
                        .clickable { onPick(n) }
                        .padding(horizontal = 14.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        if (n == 1) "솔로" else n.toString() + "인 파티",
                        color = if (on) p.accent else p.text,
                        fontSize = 14.sp,
                        fontWeight = if (on) FontWeight.Bold else FontWeight.Medium
                    )
                    Spacer(Modifier.weight(1f))
                    Text(
                        if (n == 1) "전부 내 몫" else "1/" + n.toString(),
                        color = p.muted, fontSize = 11.5.sp
                    )
                    if (base > 0L) {
                        Spacer(Modifier.width(10.dp))
                        Text(
                            meso(sharePrice(base, n)),
                            color = if (on) p.gold else p.muted,
                            fontSize = 11.5.sp
                        )
                    }
                }
            }

            Spacer(Modifier.height(6.dp))
            Text(
                "옆의 금액은 " + (boss.tiers.firstOrNull()?.name ?: "") + " 기준 예시입니다.",
                color = p.muted, fontSize = 10.5.sp
            )
            Spacer(Modifier.height(12.dp))
            ActionButton("닫기", onDismiss, Modifier.fillMaxWidth())
        }
    }
}

private data class ShareSlice(
    val name: String,
    val earned: Long,
    val target: Long,
    val color: Color
)

/**
 * 캐릭터별 비중.
 * 위쪽 누적 막대는 전체에서 각자가 차지하는 몫, 아래 줄들은 캐릭터별 진행 상황입니다.
 * 색은 캐릭터 등록 순서로 고정 배정해서, 순위가 바뀌어도 같은 캐릭터는 같은 색을 유지합니다.
 */
@Composable
private fun ShareCard(state: AppState, modifier: Modifier = Modifier) {
    val p = LocalPalette.current
    val overrides = state.priceOverrides
    val toons = state.toons
    if (toons.isEmpty()) return

    val named = toons.take(8).mapIndexed { i, t ->
        val st = t.stat(overrides)
        ShareSlice(t.name, st.earned, st.target, p.series[i])
    }
    val rest = toons.drop(8)
    val slices = if (rest.isEmpty()) named else named + ShareSlice(
        "기타 " + rest.size.toString() + "명",
        rest.sumOf { it.stat(overrides).earned },
        rest.sumOf { it.stat(overrides).target },
        p.muted
    )

    val earnedTotal = slices.sumOf { it.earned }
    val byEarned = earnedTotal > 0L
    val total = slices.sumOf { if (byEarned) it.earned else it.target }.coerceAtLeast(1L)
    val ranked = slices.sortedByDescending { if (byEarned) it.earned else it.target }
    val maxTarget = slices.maxOf { it.target }.coerceAtLeast(1L)
    val top = ranked.firstOrNull()

    Card(modifier) {
        Column(
            Modifier
                .fillMaxHeight()
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("캐릭터별 비중", color = p.text, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.width(8.dp))
                Text(if (byEarned) "획득 기준" else "목표 기준", color = p.muted, fontSize = 11.sp)
            }
            Spacer(Modifier.height(12.dp))
            run {
                if (top != null) {
                    Row(verticalAlignment = Alignment.Bottom) {
                        Text("최고 기여", color = p.muted, fontSize = 11.sp)
                        Spacer(Modifier.weight(1f))
                        Text(
                            top.name, color = p.text, fontSize = 14.sp, fontWeight = FontWeight.Bold,
                            maxLines = 1, overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.widthIn(max = 130.dp)
                        )
                        Spacer(Modifier.width(7.dp))
                        Text(
                            pct((if (byEarned) top.earned else top.target), total),
                            color = p.accent, fontSize = 14.sp, fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(Modifier.height(12.dp))
                }

                // 누적 막대 — 조각 사이 2dp 간격으로 경계를 분리
                Row(
                    Modifier.fillMaxWidth().height(14.dp),
                    horizontalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    var drew = false
                    ranked.forEach { sl ->
                        val v = if (byEarned) sl.earned else sl.target
                        if (v > 0L) {
                            drew = true
                            Box(
                                Modifier
                                    .weight(v.toFloat())
                                    .fillMaxHeight()
                                    .background(sl.color, RoundedCornerShape(4.dp))
                            )
                        }
                    }
                    if (!drew) {
                        Box(Modifier.weight(1f).fillMaxHeight().background(p.panel3, RoundedCornerShape(4.dp)))
                    }
                }

                Spacer(Modifier.height(6.dp))
                Text(
                    if (byEarned) "아래 줄의 진한 부분이 클리어, 연한 부분이 남은 몫입니다."
                    else "아직 클리어가 없어 목표 기준으로 나눴습니다.",
                    color = p.muted, fontSize = 10.5.sp
                )
                Spacer(Modifier.height(14.dp))

                ranked.forEachIndexed { i, sl ->
                    if (i > 0) Spacer(Modifier.height(13.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(9.dp).background(sl.color, RoundedCornerShape(3.dp)))
                        Spacer(Modifier.width(9.dp))
                        Text(
                            sl.name, color = p.text, fontSize = 13.sp, fontWeight = FontWeight.Medium,
                            maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f)
                        )
                        Text(
                            pct((if (byEarned) sl.earned else sl.target), total),
                            color = p.text2, fontSize = 12.sp, fontWeight = FontWeight.Bold
                        )
                        Spacer(Modifier.width(12.dp))
                        Text(
                            meso(sl.earned), color = p.gold, fontSize = 12.sp,
                            textAlign = TextAlign.End, modifier = Modifier.widthIn(min = 78.dp)
                        )
                    }
                    Spacer(Modifier.height(6.dp))
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .background(p.panel3, RoundedCornerShape(99.dp))
                    ) {
                        Box(
                            Modifier
                                .fillMaxWidth((sl.target.toFloat() / maxTarget).coerceIn(0f, 1f))
                                .fillMaxHeight()
                                .background(sl.color.copy(alpha = 0.30f), RoundedCornerShape(99.dp))
                        ) {
                            Box(
                                Modifier
                                    .fillMaxWidth(
                                        if (sl.target > 0L) (sl.earned.toFloat() / sl.target).coerceIn(0f, 1f) else 0f
                                    )
                                    .fillMaxHeight()
                                    .background(sl.color, RoundedCornerShape(99.dp))
                            )
                        }
                    }
                }

                Spacer(Modifier.height(16.dp))
                Box(Modifier.fillMaxWidth().height(1.dp).background(p.lineSoft))
                Spacer(Modifier.height(12.dp))
                val tot = toons.totals(overrides)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("합계", color = p.text, fontSize = 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Text(tot.done.toString() + "/" + tot.total.toString(), color = p.text2, fontSize = 12.sp)
                    Spacer(Modifier.width(12.dp))
                    Text(meso(tot.earned), color = p.gold, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

/** "42.4%" */
private fun pct(value: Long, total: Long): String =
    String.format(Locale.KOREA, "%.1f%%", if (total > 0L) 100.0 * value / total else 0.0)

/* ══════════════════════════════════════════════════════════════
 * 기록 탭 — 날짜별로 자동 적립
 * ══════════════════════════════════════════════════════════════ */

@Composable
private fun HistoryTab(store: Store) {
    val p = LocalPalette.current
    val log = store.state.log
    val byDate = log.byDate()

    var month by remember { mutableStateOf(Dates.today().withDayOfMonth(1)) }
    var picked by remember { mutableStateOf(Dates.todayKey()) }

    val monthTotal = log.sumBetween(month, month.plusMonths(1))
    val maxDay = byDate.values.maxOrNull() ?: 1L

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("기록", color = p.text, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.width(8.dp))
            Text("보스를 체크하면 그날로 쌓입니다", color = p.muted, fontSize = 11.sp)
        }

        // 달력
        Card {
            Column(Modifier.padding(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "‹", color = p.text2, fontSize = 20.sp, fontWeight = FontWeight.Bold,
                        modifier = Modifier.clickable { month = month.minusMonths(1) }.padding(horizontal = 8.dp)
                    )
                    Text(
                        month.year.toString() + "년 " + month.monthValue.toString() + "월",
                        color = p.text, fontSize = 15.sp, fontWeight = FontWeight.Bold
                    )
                    Text(
                        "›", color = p.text2, fontSize = 20.sp, fontWeight = FontWeight.Bold,
                        modifier = Modifier.clickable { month = month.plusMonths(1) }.padding(horizontal = 8.dp)
                    )
                    Spacer(Modifier.weight(1f))
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("월 합계", color = p.muted, fontSize = 10.sp)
                        Text(meso(monthTotal), color = p.gold, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth()) {
                    listOf("일", "월", "화", "수", "목", "금", "토").forEachIndexed { i, d ->
                        Text(
                            d,
                            color = if (i == 0) p.extreme.copy(alpha = 0.8f) else p.muted,
                            fontSize = 10.5.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
                Spacer(Modifier.height(6.dp))

                val first = month.withDayOfMonth(1)
                val lead = first.dayOfWeek.value % 7
                val cells = ArrayList<LocalDate?>()
                repeat(lead) { cells.add(null) }
                for (d in 1..month.lengthOfMonth()) cells.add(first.withDayOfMonth(d))
                while (cells.size % 7 != 0) cells.add(null)

                cells.chunked(7).forEach { week ->
                    Row(Modifier.fillMaxWidth()) {
                        week.forEach { day ->
                            DayCell(day, byDate, maxDay, picked, Modifier.weight(1f)) { picked = it }
                        }
                    }
                }
            }
        }

        // 고른 날 상세
        val dayItems = log.onDate(picked)
        val dayTotal = dayItems.sumOf { it.meso }
        Card {
            Column(Modifier.padding(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    val d = Dates.parse(picked)
                    Text(
                        if (d != null) Dates.label(d) else picked,
                        color = p.text, fontSize = 15.sp, fontWeight = FontWeight.Bold
                    )
                    if (picked == Dates.todayKey()) {
                        Spacer(Modifier.width(7.dp))
                        Text(
                            "오늘", color = p.accent, fontSize = 10.5.sp, fontWeight = FontWeight.Bold,
                            modifier = Modifier
                                .background(p.accentWash, RoundedCornerShape(6.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                    Spacer(Modifier.weight(1f))
                    Text(
                        if (dayTotal > 0) meso(dayTotal) else "기록 없음",
                        color = if (dayTotal > 0) p.gold else p.muted,
                        fontSize = 14.sp, fontWeight = FontWeight.Bold
                    )
                }
            }
            if (dayItems.isNotEmpty()) {
                Box(Modifier.fillMaxWidth().height(1.dp).background(p.lineSoft))
                dayItems.asReversed().forEach { e ->
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            e.toonName, color = p.text2, fontSize = 11.5.sp,
                            maxLines = 1, overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.widthIn(max = 84.dp)
                        )
                        Spacer(Modifier.width(10.dp))
                        Text(
                            Bosses.byId[e.bossId]?.name ?: e.bossId,
                            color = p.text, fontSize = 13.sp,
                            maxLines = 1, overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f)
                        )
                        Spacer(Modifier.width(6.dp))
                        TierPill(e.tier)
                        if (e.party > 1) {
                            Spacer(Modifier.width(5.dp))
                            Text(e.party.toString() + "인", color = p.normal, fontSize = 10.5.sp)
                        }
                        Spacer(Modifier.width(9.dp))
                        Text(
                            meso(e.meso), color = p.gold, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.End, modifier = Modifier.widthIn(min = 66.dp)
                        )
                    }
                    Box(Modifier.fillMaxWidth().height(1.dp).background(p.lineSoft))
                }
            }
        }

        WeekCompareCard(log)
    }
}

@Composable
private fun DayCell(
    day: LocalDate?,
    byDate: Map<String, Long>,
    maxDay: Long,
    picked: String,
    modifier: Modifier,
    onPick: (String) -> Unit
) {
    val p = LocalPalette.current
    if (day == null) {
        Box(modifier.height(50.dp))
        return
    }
    val key = Dates.key(day)
    val value = byDate[key] ?: 0L
    val on = key == picked
    val intensity = if (maxDay > 0L && value > 0L) (0.14f + 0.42f * (value.toFloat() / maxDay)).coerceIn(0.14f, 0.56f) else 0f

    Column(
        modifier
            .padding(2.dp)
            .height(50.dp)
            .background(
                if (value > 0L) p.accent.copy(alpha = intensity) else Color.Transparent,
                RoundedCornerShape(9.dp)
            )
            .border(if (on) 1.5.dp else 0.dp, if (on) p.accent else Color.Transparent, RoundedCornerShape(9.dp))
            .clickable { onPick(key) }
            .padding(vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            day.dayOfMonth.toString(),
            color = if (value > 0L) p.text else p.muted,
            fontSize = 12.sp,
            fontWeight = if (value > 0L) FontWeight.Bold else FontWeight.Normal
        )
        if (value > 0L) {
            Spacer(Modifier.height(2.dp))
            Text(mesoShort(value), color = p.text2, fontSize = 8.5.sp, maxLines = 1)
        }
    }
}

@Composable
private fun WeekCompareCard(log: List<ClearEntry>) {
    val p = LocalPalette.current
    val ws = Dates.weekStart(Dates.today())
    val thisWeek = log.sumBetween(ws, ws.plusDays(7))
    val lastWeek = log.sumBetween(ws.minusDays(7), ws)
    val diff = thisWeek - lastWeek

    val weeks = (0 until 8).map { i ->
        val s = ws.minusDays((7L * (7 - i)))
        s to log.sumBetween(s, s.plusDays(7))
    }
    val peak = weeks.maxOfOrNull { it.second } ?: 1L

    Column {
        SectionTitle("주간 비교", "목요일 시작")
        Spacer(Modifier.height(9.dp))
        Card {
            Column(Modifier.padding(16.dp)) {
                Text(meso(thisWeek), color = p.text, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(4.dp))
                if (lastWeek > 0L) {
                    Text(
                        (if (diff >= 0) "지난주보다 +" else "지난주보다 -") + meso(kotlin.math.abs(diff)),
                        color = if (diff >= 0) p.easy else p.extreme,
                        fontSize = 12.sp
                    )
                } else {
                    Text("지난주 기록이 없어요", color = p.muted, fontSize = 12.sp)
                }

                Spacer(Modifier.height(14.dp))
                CompareRow("지난주", lastWeek, maxOf(thisWeek, lastWeek, 1L), p.muted)
                Spacer(Modifier.height(7.dp))
                CompareRow("이번 주", thisWeek, maxOf(thisWeek, lastWeek, 1L), p.accent)

                Spacer(Modifier.height(16.dp))
                Text("최근 8주", color = p.muted, fontSize = 11.sp)
                Spacer(Modifier.height(10.dp))
                Row(
                    Modifier.fillMaxWidth().height(78.dp),
                    verticalAlignment = Alignment.Bottom,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    weeks.forEachIndexed { i, w ->
                        val h = if (peak > 0L) (6 + (66 * w.second / peak)).toInt() else 6
                        Column(
                            Modifier.weight(1f),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Box(
                                Modifier
                                    .fillMaxWidth()
                                    .height(h.dp)
                                    .background(
                                        if (i == 7) p.accent else p.accentDim,
                                        RoundedCornerShape(5.dp)
                                    )
                            )
                            Spacer(Modifier.height(5.dp))
                            Text(
                                if (i == 7) "이번" else w.first.monthValue.toString() + "/" + w.first.dayOfMonth.toString(),
                                color = p.muted, fontSize = 8.5.sp, maxLines = 1
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CompareRow(label: String, value: Long, peak: Long, tone: Color) {
    val p = LocalPalette.current
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = p.muted, fontSize = 11.5.sp, modifier = Modifier.widthIn(min = 48.dp))
        Spacer(Modifier.width(8.dp))
        Box(Modifier.weight(1f)) {
            Bar(if (peak > 0L) value.toFloat() / peak else 0f, 9.dp, tone, p.panel3)
        }
        Spacer(Modifier.width(9.dp))
        Text(
            mesoShort(value).ifBlank { "0" },
            color = p.text2, fontSize = 11.5.sp, textAlign = TextAlign.End,
            modifier = Modifier.widthIn(min = 52.dp)
        )
    }
}

/* ══════════════════════════════════════════════════════════════
 * 더보기 탭
 * ══════════════════════════════════════════════════════════════ */

@Composable
private fun MoreTab(
    store: Store,
    onImport: () -> Unit,
    onMatrix: () -> Unit,
    onPrices: () -> Unit,
    onApiTool: () -> Unit
) {
    val p = LocalPalette.current
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("더보기", color = p.text, fontSize = 20.sp, fontWeight = FontWeight.Bold)

        Card {
            MenuRow("캐릭터 불러오기", "넥슨 API 키로 계정의 캐릭터 조회", onImport)
            Box(Modifier.fillMaxWidth().height(1.dp).background(p.lineSoft))
            MenuRow("보스 한 번에 편집", "보스별로 캐릭터 전원의 난이도 지정", onMatrix)
            Box(Modifier.fillMaxWidth().height(1.dp).background(p.lineSoft))
            MenuRow("결정석 가격 수정", "패치로 시세가 바뀌면 여기서", onPrices)
            Box(Modifier.fillMaxWidth().height(1.dp).background(p.lineSoft))
            MenuRow("API 응답 확인", "넥슨 API를 직접 호출해 보기", onApiTool)
        }

        Card {
            Row(
                Modifier
                    .fillMaxWidth()
                    .clickable { store.toggleAutoSync() }
                    .padding(15.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                CheckMark(store.state.autoSync)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("돌아올 때마다 자동 동기화", color = p.text, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                    Text(
                        "게임에서 캐시샵을 찍고 앱을 열면 바로 반영됩니다",
                        color = p.muted, fontSize = 11.sp
                    )
                }
            }
        }

        if (store.state.lastApiDate.isNotBlank()) {
            Text(
                "게임 데이터 기준 " + apiDateLabel(store.state.lastApiDate),
                color = p.muted, fontSize = 11.5.sp
            )
        }

        Text(
            "결정석 가격은 2026년 7월 1일 기준입니다. 파티로 잡으면 인원수만큼 나뉘고 소수점은 버립니다.\n" +
                "주간보스와 플래그·수로는 매주 목요일 0시, 검은 마법사는 매월 1일에 초기화됩니다.",
            color = p.muted, fontSize = 11.5.sp, lineHeight = 18.sp
        )
    }
}

@Composable
private fun MenuRow(title: String, sub: String, onClick: () -> Unit) {
    val p = LocalPalette.current
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(15.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = p.text, fontSize = 14.5.sp, fontWeight = FontWeight.Medium)
            Text(sub, color = p.muted, fontSize = 11.sp)
        }
        Text("›", color = p.muted, fontSize = 18.sp)
    }
}

/* ══════════════════════════════════════════════════════════════
 * 보스 선택
 * ══════════════════════════════════════════════════════════════ */

@Composable
private fun PickerScreen(store: Store, toonId: String, onBack: () -> Unit) {
    val p = LocalPalette.current
    val toon = store.state.toons.firstOrNull { it.id == toonId }
    if (toon == null) {
        LaunchedEffect(Unit) { onBack() }
        return
    }
    val s = toon.stat(store.state.priceOverrides)
    val weeklyCount = toon.bosses.keys.count { Bosses.byId[it]?.monthly == false }

    Column(Modifier.fillMaxSize()) {
        TopBar(
            title = toon.name,
            sub = "선택 " + weeklyCount.toString() + "/" + Bosses.CAP_CHARACTER.toString() +
                " · 주간 " + meso(s.target),
            onBack = onBack
        ) {
            Text(
                "삭제", color = p.extreme, fontSize = 12.5.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .clickable {
                        store.update { st -> st.copy(toons = st.toons.filterNot { it.id == toonId }) }
                        onBack()
                    }
                    .padding(6.dp)
            )
        }

        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            ActionButton("전체 비우기", {
                store.updateToon(toonId) { it.copy(bosses = emptyMap(), done = emptySet()) }
            }, tone = p.text2)
        }

        LazyColumn(
            Modifier.weight(1f),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 28.dp)
        ) {
            items(Bosses.all) { boss ->
                val current = toon.bosses[boss.id]
                Column(Modifier.fillMaxWidth().padding(vertical = 11.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(boss.name, color = p.text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                        if (boss.monthly) {
                            Spacer(Modifier.width(6.dp))
                            Text("월간", color = p.hard, fontSize = 10.5.sp)
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(
                        Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Seg("안 함", null, current == null, p.muted) {
                            store.updateToon(toonId) {
                                it.copy(bosses = it.bosses - boss.id, done = it.done - boss.id)
                            }
                        }
                        boss.tiers.forEach { t ->
                            val shown = priceText(priceOf(boss.id, t.name, store.state.priceOverrides))
                            Seg(t.name, shown, current == t.name, p.tier(t.name)) {
                                store.updateToon(toonId) { it.copy(bosses = it.bosses + (boss.id to t.name)) }
                            }
                        }
                    }
                    Spacer(Modifier.height(11.dp))
                    Box(Modifier.fillMaxWidth().height(1.dp).background(p.lineSoft))
                }
            }
        }
    }
}

@Composable
private fun Seg(label: String, price: String?, selected: Boolean, accent: Color, onClick: () -> Unit) {
    val p = LocalPalette.current
    Row(
        Modifier
            .background(if (selected) accent.copy(alpha = 0.18f) else p.panel, RoundedCornerShape(10.dp))
            .border(1.dp, if (selected) accent else p.line, RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            label,
            color = if (selected) accent else p.muted,
            fontSize = 12.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
        )
        if (price != null) {
            Spacer(Modifier.width(7.dp))
            Text(price, color = if (selected) p.text2 else p.muted, fontSize = 10.5.sp)
        }
    }
}

/* ══════════════════════════════════════════════════════════════
 * 한 번에 편집
 * ══════════════════════════════════════════════════════════════ */

private fun nextTier(boss: Boss, current: String?): String? {
    val names = boss.tiers.map { it.name }
    val i = if (current == null) -1 else names.indexOf(current)
    return if (i + 1 >= names.size) null else names[i + 1]
}

@Composable
private fun MatrixScreen(store: Store, onBack: () -> Unit) {
    val p = LocalPalette.current
    val toons = store.state.toons

    Column(Modifier.fillMaxSize()) {
        TopBar("보스 한 번에 편집", "칩을 누르면 안 함 → 이지 → 노멀 → 하드 … 순환", onBack)

        Row(
            Modifier
                .fillMaxWidth()
                .background(p.panel2)
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 9.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            toons.forEach { t ->
                val n = t.bosses.keys.count { Bosses.byId[it]?.monthly == false }
                Text(
                    t.name + " " + n.toString(),
                    color = if (n > Bosses.CAP_CHARACTER) p.extreme else p.muted,
                    fontSize = 11.sp, maxLines = 1
                )
            }
        }

        LazyColumn(
            Modifier.weight(1f),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 28.dp)
        ) {
            items(Bosses.all) { boss ->
                Column(Modifier.fillMaxWidth().padding(vertical = 10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(boss.name, color = p.text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                        if (boss.monthly) {
                            Spacer(Modifier.width(6.dp))
                            Text("월간", color = p.hard, fontSize = 10.5.sp)
                        }
                        Spacer(Modifier.weight(1f))
                        val n = toons.count { it.bosses.containsKey(boss.id) }
                        if (n > 0) Text(n.toString() + "명", color = p.accent, fontSize = 11.sp)
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(
                        Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        toons.forEach { t ->
                            MatrixChip(t.name, t.bosses[boss.id]) {
                                store.updateToon(t.id) { tt ->
                                    val nx = nextTier(boss, tt.bosses[boss.id])
                                    if (nx == null) tt.copy(
                                        bosses = tt.bosses - boss.id,
                                        done = tt.done - boss.id
                                    ) else tt.copy(bosses = tt.bosses + (boss.id to nx))
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(11.dp))
                    Box(Modifier.fillMaxWidth().height(1.dp).background(p.lineSoft))
                }
            }
        }
    }
}

@Composable
private fun MatrixChip(name: String, tier: String?, onClick: () -> Unit) {
    val p = LocalPalette.current
    val accent = if (tier == null) p.line else p.tier(tier)
    Column(
        Modifier
            .widthIn(min = 78.dp)
            .background(if (tier == null) p.panel else accent.copy(alpha = 0.14f), RoundedCornerShape(10.dp))
            .border(1.dp, accent, RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 9.dp, vertical = 8.dp)
    ) {
        Text(
            name,
            color = if (tier == null) p.muted else p.text,
            fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
            modifier = Modifier.widthIn(max = 92.dp)
        )
        Spacer(Modifier.height(3.dp))
        Text(
            tier ?: "안 함",
            color = if (tier == null) p.muted else p.tier(tier),
            fontSize = 12.sp,
            fontWeight = if (tier == null) FontWeight.Normal else FontWeight.Bold
        )
    }
}

/* ══════════════════════════════════════════════════════════════
 * 결정석 가격 수정
 * ══════════════════════════════════════════════════════════════ */

@Composable
private fun PriceScreen(store: Store, onBack: () -> Unit) {
    val p = LocalPalette.current
    var drafts by remember { mutableStateOf<Map<String, String>>(emptyMap()) }
    val overrides = store.state.priceOverrides

    Column(Modifier.fillMaxSize()) {
        TopBar("결정석 가격 수정", "단위는 만 메소 · 비우면 기본값", onBack) {
            if (overrides.isNotEmpty()) {
                Text(
                    "되돌리기", color = p.extreme, fontSize = 12.5.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .clickable {
                            drafts = emptyMap()
                            store.update { it.copy(priceOverrides = emptyMap()) }
                        }
                        .padding(6.dp)
                )
            }
        }

        LazyColumn(
            Modifier.weight(1f),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 10.dp, bottom = 28.dp)
        ) {
            items(Bosses.all) { boss ->
                Column(Modifier.fillMaxWidth().padding(vertical = 9.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(boss.name, color = p.text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.weight(1f))
                        Text("최대 " + boss.maxParty.toString() + "인", color = p.muted, fontSize = 10.5.sp)
                    }
                    Spacer(Modifier.height(6.dp))
                    boss.tiers.forEach { t ->
                        val key = priceKey(boss.id, t.name)
                        val current = overrides[key] ?: t.price
                        val text = drafts[key] ?: if (current > 0L) current.toString() else ""
                        Row(
                            Modifier.fillMaxWidth().padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            TierPill(t.name)
                            Spacer(Modifier.width(10.dp))
                            Text(
                                if (t.price > 0L) "기본 " + meso(t.price) else "기본값 없음",
                                color = p.muted, fontSize = 10.5.sp
                            )
                            Spacer(Modifier.weight(1f))
                            Box(
                                Modifier
                                    .widthIn(min = 100.dp)
                                    .background(p.panel2, RoundedCornerShape(10.dp))
                                    .border(
                                        1.dp,
                                        if (overrides.containsKey(key)) p.accent else p.line,
                                        RoundedCornerShape(10.dp)
                                    )
                                    .padding(horizontal = 10.dp, vertical = 8.dp)
                            ) {
                                if (text.isEmpty()) Text("0", color = p.muted, fontSize = 13.sp)
                                BasicTextField(
                                    value = text,
                                    onValueChange = { raw ->
                                        val digits = raw.filter { ch -> ch.isDigit() }.take(9)
                                        drafts = drafts + (key to digits)
                                        store.setPrice(boss.id, t.name, digits.toLongOrNull() ?: 0L)
                                    },
                                    singleLine = true,
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    textStyle = TextStyle(color = p.text, fontSize = 13.sp),
                                    cursorBrush = SolidColor(p.accent),
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                            Spacer(Modifier.width(7.dp))
                            Text("만", color = p.muted, fontSize = 11.sp)
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                    Box(Modifier.fillMaxWidth().height(1.dp).background(p.lineSoft))
                }
            }
        }
    }
}

/* ══════════════════════════════════════════════════════════════
 * 캐릭터 불러오기
 * ══════════════════════════════════════════════════════════════ */

@Composable
private fun ImportScreen(store: Store, onApiTool: () -> Unit, onBack: () -> Unit) {
    val p = LocalPalette.current
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()

    var key by remember { mutableStateOf(store.state.apiKey) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var raw by remember { mutableStateOf<String?>(null) }
    var showRaw by remember { mutableStateOf(false) }
    var found by remember { mutableStateOf<List<NexonApi.Remote>>(emptyList()) }
    var picked by remember { mutableStateOf<Set<String>>(emptySet()) }
    var manual by remember { mutableStateOf("") }

    val existing = store.state.toons.map { it.name }.toSet()

    Column(Modifier.fillMaxSize()) {
        TopBar("캐릭터 불러오기", null, onBack)

        Column(
            Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Card {
                Column(Modifier.padding(15.dp)) {
                    Text("넥슨 오픈 API 키", color = p.text, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "넥슨은 외부 앱에 로그인을 열어주지 않습니다. openapi.nexon.com 에서 " +
                            "본인 키를 발급받아 붙여넣으면 그 계정의 캐릭터가 조회됩니다.",
                        color = p.muted, fontSize = 12.sp, lineHeight = 18.sp
                    )
                    Spacer(Modifier.height(12.dp))
                    Field(key, { key = it }, "test_xxxxxxxx…")
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ActionButton(if (loading) "불러오는 중…" else "캐릭터 불러오기", {
                            if (!loading) {
                                loading = true; error = null; raw = null; showRaw = false
                                store.update { it.copy(apiKey = key.trim()) }
                                scope.launch {
                                    try {
                                        val list = withContext(Dispatchers.IO) { NexonApi.fetchCharacters(key) }
                                        found = list
                                        picked = emptySet()
                                    } catch (e: NexonApi.ApiException) {
                                        error = e.message; raw = e.raw; found = emptyList()
                                    } catch (e: Exception) {
                                        error = e.message ?: "알 수 없는 오류"; found = emptyList()
                                    } finally {
                                        loading = false
                                    }
                                }
                            }
                        }, filled = true)
                        ActionButton("키 발급 방법", {
                            ctx.startActivity(
                                Intent(Intent.ACTION_VIEW, Uri.parse("https://openapi.nexon.com/my-application/"))
                            )
                        }, tone = p.text2)
                    }
                }
            }

            error?.let { msg ->
                Column(
                    Modifier
                        .fillMaxWidth()
                        .background(p.extreme.copy(alpha = 0.10f), RoundedCornerShape(13.dp))
                        .border(1.dp, p.extreme.copy(alpha = 0.4f), RoundedCornerShape(13.dp))
                        .padding(13.dp)
                ) {
                    Text(msg, color = p.text, fontSize = 12.5.sp, lineHeight = 19.sp)
                    if (!raw.isNullOrBlank()) {
                        Spacer(Modifier.height(8.dp))
                        Text(
                            if (showRaw) "응답 원문 접기" else "응답 원문 보기",
                            color = p.extreme, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                            modifier = Modifier.clickable { showRaw = !showRaw }
                        )
                        if (showRaw) {
                            Spacer(Modifier.height(6.dp))
                            Text(raw!!.take(1200), color = p.muted, fontSize = 11.sp, lineHeight = 16.sp)
                        }
                    }
                }
            }

            if (found.isNotEmpty()) {
                Column {
                    val selectable = found.filter { it.name !in existing }.map { it.name }.toSet()
                    SectionTitle(
                        "불러온 캐릭터", found.size.toString() + "명",
                        if (picked.size >= selectable.size && selectable.isNotEmpty()) "전체 해제" else "전체 선택"
                    ) {
                        picked = if (picked.size >= selectable.size) emptySet() else selectable
                    }
                    Spacer(Modifier.height(9.dp))
                    Card {
                        found.forEach { r ->
                            val already = r.name in existing
                            val on = r.name in picked
                            Row(
                                Modifier
                                    .fillMaxWidth()
                                    .clickable(enabled = !already) {
                                        picked = if (on) picked - r.name else picked + r.name
                                    }
                                    .padding(horizontal = 15.dp, vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                CheckMark(on && !already)
                                Spacer(Modifier.width(11.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(
                                        r.name,
                                        color = if (already) p.muted else p.text,
                                        fontSize = 14.sp, fontWeight = FontWeight.Medium, maxLines = 1
                                    )
                                    Text(
                                        listOfNotNull(
                                            r.world.takeIf { it.isNotBlank() },
                                            r.job.takeIf { it.isNotBlank() },
                                            if (r.level > 0) "Lv." + r.level.toString() else null
                                        ).joinToString(" · "),
                                        color = p.muted, fontSize = 11.sp, maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                                if (already) Text("추가됨", color = p.muted, fontSize = 11.sp)
                            }
                            Box(Modifier.fillMaxWidth().height(1.dp).background(p.lineSoft))
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    ActionButton("선택한 " + picked.size.toString() + "명 추가", {
                        val add = found.filter { it.name in picked && it.name !in existing }
                        if (add.isNotEmpty()) {
                            store.update { st ->
                                st.copy(toons = st.toons + add.map { r ->
                                    Toon(
                                        id = r.name + "@" + r.world + "#" + System.nanoTime(),
                                        name = r.name,
                                        ocid = r.ocid,
                                        world = r.world,
                                        job = r.job,
                                        level = r.level
                                    )
                                })
                            }
                            onBack()
                        }
                    }, Modifier.fillMaxWidth(), filled = true)
                }
            }

            Card {
                Column(Modifier.padding(15.dp)) {
                    Text("직접 추가", color = p.text, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    Text("API 없이 이름만으로도 추가할 수 있어요.", color = p.muted, fontSize = 12.sp)
                    Spacer(Modifier.height(12.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.weight(1f)) { Field(manual, { manual = it }, "캐릭터 이름") }
                        Spacer(Modifier.width(8.dp))
                        ActionButton("추가", {
                            val nm = manual.trim()
                            if (nm.isNotEmpty()) {
                                store.update { st ->
                                    st.copy(toons = st.toons + Toon(id = nm + "#" + System.nanoTime(), name = nm))
                                }
                                manual = ""
                                onBack()
                            }
                        })
                    }
                }
            }

            Card {
                Column(Modifier.padding(15.dp)) {
                    Text("API 응답 확인", color = p.text, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "넥슨 API를 직접 호출해 응답을 그대로 볼 수 있습니다. 문제가 생겼을 때 쓰세요.",
                        color = p.muted, fontSize = 12.sp, lineHeight = 18.sp
                    )
                    Spacer(Modifier.height(12.dp))
                    ActionButton("열기", onApiTool, tone = p.text2)
                }
            }
        }
    }
}

@Composable
private fun Field(value: String, onChange: (String) -> Unit, hint: String) {
    val p = LocalPalette.current
    Box(
        Modifier
            .fillMaxWidth()
            .background(p.panel2, RoundedCornerShape(11.dp))
            .border(1.dp, p.line, RoundedCornerShape(11.dp))
            .padding(horizontal = 12.dp, vertical = 11.dp)
    ) {
        if (value.isEmpty()) Text(hint, color = p.muted, fontSize = 13.sp)
        BasicTextField(
            value = value,
            onValueChange = onChange,
            singleLine = true,
            textStyle = TextStyle(color = p.text, fontSize = 13.sp),
            cursorBrush = SolidColor(p.accent),
            modifier = Modifier.fillMaxWidth()
        )
    }
}

/* ══════════════════════════════════════════════════════════════
 * API 응답 확인
 * ══════════════════════════════════════════════════════════════ */

private val CANDIDATE_PATHS = listOf(
    "/maplestory/v1/character/list",
    "/maplestory/v1/scheduler/character-state",
    "/maplestory/v1/id?character_name="
)

@Composable
private fun ApiToolScreen(store: Store, onBack: () -> Unit) {
    val p = LocalPalette.current
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current

    var path by remember { mutableStateOf(CANDIDATE_PATHS[0]) }
    var loading by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf<String?>(null) }
    var ok by remember { mutableStateOf(false) }
    var body by remember { mutableStateOf("") }

    val key = store.state.apiKey
    val withOcid = store.state.toons.filter { it.ocid.isNotBlank() }

    Column(Modifier.fillMaxSize()) {
        TopBar("API 응답 확인", if (key.isBlank()) "API 키 없음" else "API 키 저장됨", onBack) {
            if (body.isNotEmpty()) {
                Text(
                    "복사", color = p.accent, fontSize = 12.5.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.clickable { clipboard.setText(AnnotatedString(body)) }.padding(6.dp)
                )
            }
        }

        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Card {
                Column(Modifier.padding(15.dp)) {
                    Text(NexonApi.HOST, color = p.muted, fontSize = 11.sp)
                    Spacer(Modifier.height(6.dp))
                    Field(path, { path = it }, "/maplestory/v1/…")
                    Spacer(Modifier.height(9.dp))
                    Row(
                        Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        CANDIDATE_PATHS.forEach { c ->
                            Seg(c.removePrefix("/maplestory/v1/"), null, path == c, p.normal) { path = c }
                        }
                    }
                    if (withOcid.isNotEmpty()) {
                        Spacer(Modifier.height(9.dp))
                        Text("ocid 붙이기", color = p.muted, fontSize = 11.sp)
                        Spacer(Modifier.height(5.dp))
                        Row(
                            Modifier.horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            withOcid.forEach { t ->
                                Seg(t.name, null, false, p.hard) {
                                    path = path.substringBefore("?") + "?ocid=" + t.ocid
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(13.dp))
                    ActionButton(if (loading) "호출 중…" else "호출하기", {
                        if (!loading) {
                            loading = true; status = null; body = ""
                            scope.launch {
                                try {
                                    val r = withContext(Dispatchers.IO) { NexonApi.raw(path, key) }
                                    ok = r.code == 200
                                    status = "HTTP " + r.code.toString()
                                    body = NexonApi.pretty(r.body)
                                } catch (e: NexonApi.ApiException) {
                                    ok = false; status = "실패"
                                    body = (e.message ?: "") + (if (e.raw.isBlank()) "" else "\n\n" + e.raw)
                                } catch (e: Exception) {
                                    ok = false; status = "실패"; body = e.message ?: "알 수 없는 오류"
                                } finally {
                                    loading = false
                                }
                            }
                        }
                    }, Modifier.fillMaxWidth(), filled = true)
                }
            }

            status?.let { st ->
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            st,
                            color = if (ok) p.easy else p.extreme,
                            fontSize = 12.sp, fontWeight = FontWeight.Bold,
                            modifier = Modifier
                                .background((if (ok) p.easy else p.extreme).copy(alpha = 0.15f), RoundedCornerShape(7.dp))
                                .padding(horizontal = 9.dp, vertical = 4.dp)
                        )
                        Spacer(Modifier.weight(1f))
                        Text(body.length.toString() + "자", color = p.muted, fontSize = 11.sp)
                    }
                    Spacer(Modifier.height(9.dp))
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .background(p.panel2, RoundedCornerShape(13.dp))
                            .border(1.dp, p.lineSoft, RoundedCornerShape(13.dp))
                            .padding(13.dp)
                    ) {
                        SelectionContainer {
                            Text(body.take(20000), color = p.text2, fontSize = 11.sp, lineHeight = 16.sp)
                        }
                    }
                    if (body.length > 20000) {
                        Spacer(Modifier.height(6.dp))
                        Text("앞부분만 표시했습니다. 복사 버튼은 전체를 복사합니다.", color = p.muted, fontSize = 11.sp)
                    }
                }
            }
        }
    }
}

/* ══════════════════════════════════════════════════════════════
 * 동기화
 * ══════════════════════════════════════════════════════════════ */

private data class SyncOutcome(
    val ok: Int,
    val failed: List<String>,
    val bossesAdded: Int,
    val bossesRemoved: Int,
    val newlyCleared: Int,
    val apiDate: String
)

private suspend fun syncAll(store: Store, onProgress: (String) -> Unit): SyncOutcome {
    val key = store.state.apiKey
    val toons = store.state.toons
    var ok = 0
    var added = 0
    var removed = 0
    var cleared = 0
    var apiDate = ""
    val failed = ArrayList<String>()

    for ((idx, t) in toons.withIndex()) {
        onProgress("동기화 중… (" + (idx + 1).toString() + "/" + toons.size.toString() + ") " + t.name)
        try {
            val ocid = if (t.ocid.isNotBlank()) t.ocid
            else withContext(Dispatchers.IO) { NexonApi.fetchOcid(key, t.name) }
            val st = withContext(Dispatchers.IO) { NexonApi.fetchSchedulerState(key, ocid) }
            if (apiDate.isBlank()) apiDate = st.date

            val before = store.state.toons.firstOrNull { it.id == t.id } ?: t
            val after = applyScheduler(before.copy(ocid = ocid), st)
            val newClears = after.done - before.done

            added += (after.bosses.keys - before.bosses.keys).size
            removed += (before.bosses.keys - after.bosses.keys).size
            cleared += newClears.size

            store.updateToon(t.id) { after }
            store.appendClears(t.id, newClears)
            ok++
        } catch (e: Exception) {
            failed.add(t.name)
        }
        delay(120)
    }

    if (apiDate.isNotBlank()) store.update { it.copy(lastApiDate = apiDate) }
    return SyncOutcome(ok, failed, added, removed, cleared, apiDate)
}

private fun summarizeSync(r: SyncOutcome): String {
    val changes = ArrayList<String>()
    if (r.bossesAdded > 0) changes.add("보스 +" + r.bossesAdded.toString())
    if (r.bossesRemoved > 0) changes.add("보스 -" + r.bossesRemoved.toString())
    if (r.newlyCleared > 0) changes.add("클리어 +" + r.newlyCleared.toString())

    val head = when {
        r.ok == 0 -> "동기화 실패"
        changes.isEmpty() -> r.ok.toString() + "명 확인 · 바뀐 것 없음"
        else -> r.ok.toString() + "명 갱신 · " + changes.joinToString(" · ")
    }
    val date = if (r.apiDate.isNotBlank()) "  (게임 데이터 기준 " + apiDateLabel(r.apiDate) + ")" else ""
    val fail = if (r.failed.isEmpty()) "" else "\n실패 " + r.failed.size.toString() + "명: " + r.failed.joinToString(", ")
    return head + date + fail
}

/** "2026-09-09T00:00+09:00" → "9/9 00:00" */
private fun apiDateLabel(rawDate: String): String = try {
    val t = java.time.OffsetDateTime.parse(rawDate)
    java.lang.String.format(
        Locale.KOREA, "%d/%d %02d:%02d",
        t.monthValue, t.dayOfMonth, t.hour, t.minute
    )
} catch (e: Exception) {
    rawDate
}
