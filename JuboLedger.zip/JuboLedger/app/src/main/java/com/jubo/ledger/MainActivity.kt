package com.jubo.ledger

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material3.Text
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val store = Store(applicationContext)
        setContent {
            JuboTheme {
                App(store)
            }
        }
    }
}

private sealed interface Screen {
    data object Home : Screen
    data class Picker(val toonId: String) : Screen
    data object Import : Screen
    data object ApiTool : Screen
    data object Matrix : Screen
}

/* ══════════════════════════════════════════════════════════════
 * 루트
 * ══════════════════════════════════════════════════════════════ */

@Composable
private fun App(store: Store) {
    val p = LocalPalette.current
    var screen by remember { mutableStateOf<Screen>(Screen.Home) }
    var selected by remember { mutableStateOf(0) }
    var now by remember { mutableStateOf(System.currentTimeMillis()) }

    LaunchedEffect(Unit) {
        while (true) {
            delay(1000)
            now = System.currentTimeMillis()
            store.refreshResets()
        }
    }

    val state = store.state
    val sel = if (state.toons.isEmpty()) 0 else selected.coerceIn(0, state.toons.size - 1)

    Box(
        Modifier
            .fillMaxSize()
            .background(p.ground)
            .safeDrawingPadding()
    ) {
        when (val s = screen) {
            is Screen.Home -> HomeScreen(
                store = store,
                sel = sel,
                now = now,
                onSelect = { selected = it },
                onEdit = { screen = Screen.Picker(it) },
                onImport = { screen = Screen.Import },
                onMatrix = { screen = Screen.Matrix }
            )

            is Screen.Picker -> {
                BackHandler { screen = Screen.Home }
                PickerScreen(store, s.toonId) { screen = Screen.Home }
            }

            is Screen.Import -> {
                BackHandler { screen = Screen.Home }
                ImportScreen(
                    store = store,
                    onApiTool = { screen = Screen.ApiTool },
                    onBack = { screen = Screen.Home }
                )
            }

            is Screen.ApiTool -> {
                BackHandler { screen = Screen.Import }
                ApiToolScreen(store) { screen = Screen.Import }
            }

            is Screen.Matrix -> {
                BackHandler { screen = Screen.Home }
                MatrixScreen(store) { screen = Screen.Home }
            }
        }
    }
}

/* ══════════════════════════════════════════════════════════════
 * 공용 조각
 * ══════════════════════════════════════════════════════════════ */

@Composable
private fun CardBox(
    modifier: Modifier = Modifier,
    content: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit
) {
    val p = LocalPalette.current
    Column(
        modifier
            .fillMaxWidth()
            .border(1.dp, p.line, RoundedCornerShape(14.dp))
            .background(p.panel, RoundedCornerShape(14.dp)),
        content = content
    )
}

@Composable
private fun Bar(fraction: Float, height: Dp, color: Color, track: Color) {
    Box(
        Modifier
            .fillMaxWidth()
            .height(height)
            .background(track, RoundedCornerShape(99.dp))
    ) {
        Box(
            Modifier
                .fillMaxWidth(fraction.coerceIn(0f, 1f))
                .fillMaxHeight()
                .background(color, RoundedCornerShape(99.dp))
        )
    }
}

@Composable
private fun CheckSquare(checked: Boolean) {
    val p = LocalPalette.current
    Box(
        Modifier
            .size(20.dp)
            .background(
                if (checked) p.gold else Color.Transparent,
                RoundedCornerShape(6.dp)
            )
            .border(1.5.dp, if (checked) p.gold else p.line, RoundedCornerShape(6.dp)),
        contentAlignment = Alignment.Center
    ) {
        if (checked) {
            Text("✓", color = p.checkInk, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun TierChip(tier: String) {
    val p = LocalPalette.current
    val c = p.tier(tier)
    Text(
        tier,
        color = c,
        fontSize = 10.sp,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier
            .border(1.dp, c, RoundedCornerShape(5.dp))
            .padding(horizontal = 5.dp, vertical = 1.dp)
    )
}

@Composable
private fun PillButton(
    label: String,
    color: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Text(
        label,
        color = color,
        fontSize = 13.sp,
        fontWeight = FontWeight.SemiBold,
        textAlign = TextAlign.Center,
        modifier = modifier
            .border(1.dp, color.copy(alpha = 0.5f), RoundedCornerShape(9.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 13.dp, vertical = 9.dp)
    )
}

@Composable
private fun SubHead(left: String, right: String) {
    val p = LocalPalette.current
    Row(
        Modifier
            .fillMaxWidth()
            .background(p.panel2)
            .padding(horizontal = 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(left, color = p.muted, fontSize = 11.sp, fontWeight = FontWeight.Medium)
        Spacer(Modifier.weight(1f))
        Text(right, color = p.muted, fontSize = 11.sp)
    }
}

/* ══════════════════════════════════════════════════════════════
 * 홈
 * ══════════════════════════════════════════════════════════════ */

@Composable
private fun HomeScreen(
    store: Store,
    sel: Int,
    now: Long,
    onSelect: (Int) -> Unit,
    onEdit: (String) -> Unit,
    onImport: () -> Unit,
    onMatrix: () -> Unit
) {
    val state = store.state

    Column(Modifier.fillMaxSize()) {
        Header(now, onImport)
        Column(
            Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(start = 14.dp, end = 14.dp, top = 14.dp, bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            LedgerCard(state)

            if (state.toons.isEmpty()) {
                EmptyCard(onImport)
            } else {
                CharRail(state.toons, sel, onSelect, onImport, onMatrix)
                ToonCard(store, state.toons[sel], onEdit)
                OverviewCard(state.toons, onSelect)
            }

            FooterNote()
        }
    }
}

@Composable
private fun Header(now: Long, onImport: () -> Unit) {
    val p = LocalPalette.current
    Column(
        Modifier
            .fillMaxWidth()
            .background(p.ground)
            .padding(start = 14.dp, end = 14.dp, top = 12.dp, bottom = 10.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("주보 ", color = p.text, fontSize = 19.sp, fontWeight = FontWeight.Bold)
            Text("장부", color = p.gold, fontSize = 19.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            PillButton("캐릭터 불러오기", p.gold, onImport)
        }
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TimerPill("주간 초기화 (목)", Reset.countdown(Reset.nextWeekly(Reset.BOSS_DAY), now), p.gold, Modifier.weight(1f))
            TimerPill("월간 (검마)", Reset.countdown(Reset.nextMonthly(), now), p.hard, Modifier.weight(1f))
        }
        Spacer(Modifier.height(10.dp))
        Box(Modifier.fillMaxWidth().height(1.dp).background(p.lineSoft))
    }
}

@Composable
private fun TimerPill(label: String, value: String, accent: Color, modifier: Modifier) {
    val p = LocalPalette.current
    Row(
        modifier
            .border(1.dp, p.lineSoft, RoundedCornerShape(9.dp))
            .background(p.panel, RoundedCornerShape(9.dp))
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(3.dp, 14.dp).background(accent, RoundedCornerShape(2.dp)))
        Spacer(Modifier.width(7.dp))
        Text(label, color = p.muted, fontSize = 10.sp, maxLines = 1)
        Spacer(Modifier.weight(1f))
        Text(value, color = p.text, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
    }
}

@Composable
private fun LedgerCard(state: AppState) {
    val p = LocalPalette.current
    val toons = state.toons
    val t = toons.totals()
    val pct = if (t.total > 0) t.done.toFloat() / t.total else 0f

    CardBox {
        Column(Modifier.padding(16.dp)) {
            Text("이번 주 획득 결정석", color = p.muted, fontSize = 11.sp)
            Spacer(Modifier.height(4.dp))
            Row(verticalAlignment = Alignment.Bottom) {
                Text(meso(t.earned), color = p.gold, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.width(6.dp))
                Text("메소", color = p.muted, fontSize = 12.sp, modifier = Modifier.padding(bottom = 4.dp))
            }
            Spacer(Modifier.height(6.dp))
            Text(
                "목표 ${meso(t.target)} 중 ${(pct * 100).toInt()}% 완료 · 남은 물량 ${meso(t.target - t.earned)}",
                color = p.text2, fontSize = 12.sp
            )
            Spacer(Modifier.height(12.dp))
            Bar(pct, 7.dp, p.gold, p.panel3)
            Spacer(Modifier.height(12.dp))
            Box(Modifier.fillMaxWidth().height(1.dp).background(p.lineSoft))
            Spacer(Modifier.height(11.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                MeterCell(
                    "보스 클리어", "${t.done} / ${Bosses.CAP_ACCOUNT}",
                    t.done.toFloat() / Bosses.CAP_ACCOUNT,
                    over = t.done > Bosses.CAP_ACCOUNT,
                    modifier = Modifier.weight(1f)
                )
                val g = (if (state.guildFlag) 1 else 0) + (if (state.guildWater) 1 else 0)
                MeterCell(
                    "길드 숙제", "$g / 2",
                    g / 2f,
                    over = false,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
private fun MeterCell(label: String, value: String, fraction: Float, over: Boolean, modifier: Modifier) {
    val p = LocalPalette.current
    Column(modifier) {
        Row {
            Text(label, color = p.muted, fontSize = 11.sp)
            Spacer(Modifier.weight(1f))
            Text(
                value,
                color = if (over) p.extreme else p.text2,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold
            )
        }
        Spacer(Modifier.height(5.dp))
        Bar(fraction, 4.dp, if (over) p.extreme else p.normal, p.panel3)
    }
}

@Composable
private fun EmptyCard(onImport: () -> Unit) {
    val p = LocalPalette.current
    CardBox {
        Column(
            Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("아직 캐릭터가 없어요", color = p.text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(6.dp))
            Text(
                "넥슨 오픈 API 키를 넣으면 계정의 캐릭터를\n이름·레벨·직업까지 한 번에 불러옵니다.",
                color = p.muted, fontSize = 12.5.sp, textAlign = TextAlign.Center, lineHeight = 19.sp
            )
            Spacer(Modifier.height(14.dp))
            PillButton("캐릭터 불러오기", p.gold, onImport)
        }
    }
}

@Composable
private fun CharRail(
    toons: List<Toon>,
    sel: Int,
    onSelect: (Int) -> Unit,
    onImport: () -> Unit,
    onMatrix: () -> Unit
) {
    val p = LocalPalette.current
    Column {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("본부캐", color = p.text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.width(8.dp))
            Text("${toons.size}명", color = p.muted, fontSize = 11.5.sp)
            Spacer(Modifier.weight(1f))
            Text(
                "한 번에 편집",
                color = p.normal, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.clickable { onMatrix() }.padding(start = 8.dp, top = 2.dp, bottom = 2.dp)
            )
        }
        Spacer(Modifier.height(9.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(toons.size) { i ->
                val t = toons[i]
                val s = t.stat()
                val on = i == sel
                Column(
                    Modifier
                        .widthIn(min = 108.dp)
                        .border(1.dp, if (on) p.gold else p.line, RoundedCornerShape(11.dp))
                        .background(p.panel, RoundedCornerShape(11.dp))
                        .clickable { onSelect(i) }
                        .padding(horizontal = 12.dp, vertical = 9.dp)
                ) {
                    Text(
                        t.name, color = p.text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                        maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                    Spacer(Modifier.height(3.dp))
                    Text(
                        if (s.earned > 0) "${s.done} / ${s.total} · ${meso(s.earned)}"
                        else "${s.done} / ${s.total}",
                        color = if (on) p.gold else p.muted, fontSize = 11.sp, maxLines = 1
                    )
                    Spacer(Modifier.height(6.dp))
                    Bar(if (s.total > 0) s.done.toFloat() / s.total else 0f, 3.dp, p.gold, p.panel3)
                }
            }
            item {
                Box(
                    Modifier
                        .border(1.dp, p.line, RoundedCornerShape(11.dp))
                        .clickable { onImport() }
                        .padding(horizontal = 16.dp, vertical = 20.dp)
                ) {
                    Text("＋", color = p.muted, fontSize = 18.sp)
                }
            }
        }
    }
}

@Composable
private fun ToonCard(store: Store, toon: Toon, onEdit: (String) -> Unit) {
    val p = LocalPalette.current
    val s = toon.stat()
    val weekly = Bosses.weekly.filter { toon.bosses.containsKey(it.id) }
    val monthly = Bosses.monthly.filter { toon.bosses.containsKey(it.id) }

    CardBox {
        // 헤더
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(toon.name, color = p.text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                val meta = listOfNotNull(
                    toon.world.takeIf { it.isNotBlank() },
                    toon.job.takeIf { it.isNotBlank() },
                    if (toon.level > 0) "Lv.${toon.level}" else null
                ).joinToString(" · ")
                if (meta.isNotBlank()) {
                    Text(meta, color = p.muted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
            Text(
                "${s.total} / ${Bosses.CAP_CHARACTER}마리",
                color = if (s.total > Bosses.CAP_CHARACTER) p.extreme else p.muted,
                fontSize = 11.sp,
                modifier = Modifier
                    .background(p.panel2, RoundedCornerShape(99.dp))
                    .padding(horizontal = 8.dp, vertical = 3.dp)
            )
            Spacer(Modifier.width(8.dp))
            PillButton("보스 선택", p.text2, { onEdit(toon.id) })
        }
        Box(Modifier.fillMaxWidth().height(1.dp).background(p.lineSoft))

        if (weekly.isEmpty() && monthly.isEmpty()) {
            Column(
                Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 26.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("아직 도는 보스가 없어요.", color = p.muted, fontSize = 13.sp)
                Spacer(Modifier.height(10.dp))
                PillButton("보스 선택하기", p.gold, { onEdit(toon.id) })
            }
        } else {
            if (weekly.isNotEmpty()) {
                SubHead("주간보스", "${s.done} / ${s.total}")
                weekly.forEach { b -> BossRow(store, toon, b) }
            }
            if (monthly.isNotEmpty()) {
                SubHead("월간", "매월 1일 초기화")
                monthly.forEach { b -> BossRow(store, toon, b) }
            }
        }

        // 플래그·수로는 길드(계정) 단위라 최고 레벨 캐릭터 카드에만 한 번 표시합니다
        if (store.state.toons.guildRep()?.id == toon.id) {
            SubHead("길드 · 계정당 1회", "목요일 초기화")
            GuildRow("플래그 레이스", store.state.guildFlag) { store.toggleFlag() }
            GuildRow("샤레니안의 지하 수로", store.state.guildWater) { store.toggleWater() }
        }
    }
}

@Composable
private fun BossRow(store: Store, toon: Toon, boss: Boss) {
    val p = LocalPalette.current
    val tier = toon.bosses[boss.id] ?: return
    val price = Bosses.price(boss.id, tier)
    val on = toon.done.contains(boss.id)

    Row(
        Modifier
            .fillMaxWidth()
            .background(if (on) p.gold.copy(alpha = 0.07f) else Color.Transparent)
            .clickable {
                store.updateToon(toon.id) {
                    it.copy(done = if (on) it.done - boss.id else it.done + boss.id)
                }
            }
            .padding(horizontal = 14.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(3.dp, 22.dp).background(if (on) p.gold else Color.Transparent, RoundedCornerShape(2.dp)))
        Spacer(Modifier.width(8.dp))
        CheckSquare(on)
        Spacer(Modifier.width(10.dp))
        Text(
            boss.name,
            color = if (on) p.muted else p.text,
            fontSize = 14.sp,
            fontWeight = FontWeight.Medium,
            textDecoration = if (on) TextDecoration.LineThrough else null,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.widthIn(max = 150.dp)
        )
        Spacer(Modifier.width(7.dp))
        TierChip(tier)
        Spacer(Modifier.weight(1f))
        Text(
            meso(price),
            color = if (on) p.gold else p.muted,
            fontSize = 12.5.sp,
            fontWeight = if (on) FontWeight.SemiBold else FontWeight.Normal,
            maxLines = 1
        )
    }
}

@Composable
private fun GuildRow(label: String, on: Boolean, onToggle: () -> Unit) {
    val p = LocalPalette.current
    Row(
        Modifier
            .fillMaxWidth()
            .background(if (on) p.gold.copy(alpha = 0.07f) else Color.Transparent)
            .clickable(onClick = onToggle)
            .padding(horizontal = 14.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(3.dp, 22.dp).background(if (on) p.gold else Color.Transparent, RoundedCornerShape(2.dp)))
        Spacer(Modifier.width(8.dp))
        CheckSquare(on)
        Spacer(Modifier.width(10.dp))
        Text(
            label,
            color = if (on) p.muted else p.text,
            fontSize = 14.sp,
            fontWeight = FontWeight.Medium,
            textDecoration = if (on) TextDecoration.LineThrough else null
        )
    }
}

@Composable
private fun OverviewCard(toons: List<Toon>, onSelect: (Int) -> Unit) {
    val p = LocalPalette.current
    Column {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("전체 현황", color = p.text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.weight(1f))
            Text("주보 · 획득 메소", color = p.muted, fontSize = 11.5.sp)
        }
        Spacer(Modifier.height(9.dp))
        CardBox {
            toons.forEachIndexed { i, t ->
                val s = t.stat()
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clickable { onSelect(i) }
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        t.name, color = p.text, fontSize = 13.sp,
                        maxLines = 1, overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    Text("${s.done} / ${s.total}", color = p.text2, fontSize = 13.sp)
                    Spacer(Modifier.width(14.dp))
                    Text(
                        meso(s.earned), color = p.gold, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.widthIn(min = 78.dp), textAlign = TextAlign.End
                    )
                }
                Box(Modifier.fillMaxWidth().height(1.dp).background(p.lineSoft))
            }
            val t = toons.totals()
            Row(
                Modifier
                    .fillMaxWidth()
                    .background(p.panel2)
                    .padding(horizontal = 14.dp, vertical = 11.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("합계", color = p.text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                Text("${t.done} / ${t.total}", color = p.text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.width(14.dp))
                Text(
                    meso(t.earned), color = p.gold, fontSize = 13.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.widthIn(min = 78.dp), textAlign = TextAlign.End
                )
            }
        }
    }
}

@Composable
private fun FooterNote() {
    val p = LocalPalette.current
    Column {
        Box(Modifier.fillMaxWidth().height(1.dp).background(p.lineSoft))
        Spacer(Modifier.height(12.dp))
        Text(
            "결정석 가격은 2026년 6월 기준 정리표입니다. 패치로 시세가 바뀌면 Model.kt 의 가격표만 고치면 됩니다.\n" +
                "주간보스와 플래그·수로는 매주 목요일 0시, 검은 마법사는 매월 1일에 자동으로 초기화됩니다. " +
                "플래그·수로는 길드 단위라 최고 레벨 캐릭터 카드에서 한 번만 체크합니다.",
            color = p.muted, fontSize = 11.5.sp, lineHeight = 18.sp
        )
    }
}

/* ══════════════════════════════════════════════════════════════
 * 보스 선택
 * ══════════════════════════════════════════════════════════════ */

@Composable
private fun PickerScreen(store: Store, toonId: String, onBack: () -> Unit) {
    val p = LocalPalette.current
    val toon = store.state.toons.firstOrNull { it.id == toonId }
    if (toon == null) {
        LaunchedEffect(Unit) { onBack() }
        return
    }
    val s = toon.stat()

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "‹ 뒤로", color = p.text2, fontSize = 14.sp,
                modifier = Modifier.clickable { onBack() }.padding(end = 12.dp)
            )
            Column(Modifier.weight(1f)) {
                Text(toon.name, color = p.text, fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                Text(
                    "선택 ${s.total}/${Bosses.CAP_CHARACTER} · 주간 ${meso(s.target)}",
                    color = if (s.total > Bosses.CAP_CHARACTER) p.extreme else p.muted,
                    fontSize = 11.5.sp
                )
            }
            PillButton("삭제", p.extreme, {
                store.update { st -> st.copy(toons = st.toons.filterNot { it.id == toonId }) }
                onBack()
            })
        }
        Box(Modifier.fillMaxWidth().height(1.dp).background(p.line))

        Row(
            Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            PillButton("추천 세트 채우기", p.gold, {
                store.updateToon(toonId) { it.copy(bosses = Bosses.defaultSetFor(it.level)) }
            })
            PillButton("전체 비우기", p.text2, {
                store.updateToon(toonId) { it.copy(bosses = emptyMap(), done = emptySet()) }
            })
        }

        LazyColumn(
            Modifier.weight(1f),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(
                start = 14.dp, end = 14.dp, top = 6.dp, bottom = 28.dp
            )
        ) {
            items(Bosses.all) { boss ->
                val current = toon.bosses[boss.id]
                Column(Modifier.fillMaxWidth().padding(vertical = 11.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(boss.name, color = p.text, fontSize = 13.5.sp, fontWeight = FontWeight.Medium)
                        if (boss.monthly) {
                            Spacer(Modifier.width(6.dp))
                            Text("월간", color = p.muted, fontSize = 11.sp)
                        }
                    }
                    Spacer(Modifier.height(7.dp))
                    Row(
                        Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        SegButton("안 함", null, current == null, p.muted) {
                            store.updateToon(toonId) {
                                it.copy(bosses = it.bosses - boss.id, done = it.done - boss.id)
                            }
                        }
                        boss.tiers.forEach { t ->
                            SegButton(t.name, meso(t.price), current == t.name, p.tier(t.name)) {
                                store.updateToon(toonId) { it.copy(bosses = it.bosses + (boss.id to t.name)) }
                            }
                        }
                    }
                    Spacer(Modifier.height(11.dp))
                    Box(Modifier.fillMaxWidth().height(1.dp).background(p.lineSoft))
                }
            }
        }
    }
}

@Composable
private fun SegButton(label: String, price: String?, selected: Boolean, accent: Color, onClick: () -> Unit) {
    val p = LocalPalette.current
    Row(
        Modifier
            .border(1.dp, if (selected) accent else p.line, RoundedCornerShape(8.dp))
            .background(if (selected) p.panel3 else p.panel, RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 9.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            label,
            color = if (selected) accent else p.muted,
            fontSize = 11.5.sp,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal
        )
        if (price != null) {
            Spacer(Modifier.width(6.dp))
            Text(price, color = if (selected) p.text2 else p.muted, fontSize = 10.5.sp)
        }
    }
}

/* ══════════════════════════════════════════════════════════════
 * 캐릭터 불러오기 (넥슨 오픈 API)
 * ══════════════════════════════════════════════════════════════ */

@Composable
private fun ImportScreen(store: Store, onApiTool: () -> Unit, onBack: () -> Unit) {
    val p = LocalPalette.current
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()

    var key by remember { mutableStateOf(store.state.apiKey) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var raw by remember { mutableStateOf<String?>(null) }
    var showRaw by remember { mutableStateOf(false) }
    var found by remember { mutableStateOf<List<NexonApi.Remote>>(emptyList()) }
    var picked by remember { mutableStateOf<Set<String>>(emptySet()) }
    var manual by remember { mutableStateOf("") }

    val existing = store.state.toons.map { it.name }.toSet()

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(
                "‹ 뒤로", color = p.text2, fontSize = 14.sp,
                modifier = Modifier.clickable { onBack() }.padding(end = 12.dp)
            )
            Text("캐릭터 불러오기", color = p.text, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        }
        Box(Modifier.fillMaxWidth().height(1.dp).background(p.line))

        Column(
            Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // 안내
            CardBox {
                Column(Modifier.padding(14.dp)) {
                    Text("넥슨 오픈 API 키", color = p.text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "넥슨은 외부 앱에 “넥슨 ID 로그인”을 열어주지 않습니다. 대신 본인이 오픈 API 사이트에서 " +
                            "애플리케이션을 등록하고 API 키를 발급받아 아래에 붙여넣으면, 그 계정의 캐릭터가 전부 조회됩니다.",
                        color = p.muted, fontSize = 12.sp, lineHeight = 18.sp
                    )
                    Spacer(Modifier.height(10.dp))
                    KeyField(key, { key = it })
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        PillButton(if (loading) "불러오는 중…" else "캐릭터 불러오기", p.gold, {
                            if (!loading) {
                                loading = true; error = null; raw = null; showRaw = false
                                store.update { it.copy(apiKey = key.trim()) }
                                scope.launch {
                                    try {
                                        val list = withContext(Dispatchers.IO) { NexonApi.fetchCharacters(key) }
                                        found = list
                                        picked = emptySet()   // 기본은 전부 해제 — 넣을 것만 고르세요
                                    } catch (e: NexonApi.ApiException) {
                                        error = e.message; raw = e.raw; found = emptyList()
                                    } catch (e: Exception) {
                                        error = e.message ?: "알 수 없는 오류"; found = emptyList()
                                    } finally {
                                        loading = false
                                    }
                                }
                            }
                        })
                        PillButton("키 발급 방법", p.text2, {
                            ctx.startActivity(
                                Intent(Intent.ACTION_VIEW, Uri.parse("https://openapi.nexon.com/my-application/"))
                            )
                        })
                    }
                }
            }

            // 오류
            error?.let { msg ->
                Column(
                    Modifier
                        .fillMaxWidth()
                        .border(1.dp, p.extreme.copy(alpha = 0.4f), RoundedCornerShape(11.dp))
                        .background(p.extreme.copy(alpha = 0.08f), RoundedCornerShape(11.dp))
                        .padding(12.dp)
                ) {
                    Text(msg, color = p.text, fontSize = 12.5.sp, lineHeight = 19.sp)
                    if (!raw.isNullOrBlank()) {
                        Spacer(Modifier.height(8.dp))
                        Text(
                            if (showRaw) "응답 원문 접기" else "응답 원문 보기",
                            color = p.extreme, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.clickable { showRaw = !showRaw }
                        )
                        if (showRaw) {
                            Spacer(Modifier.height(6.dp))
                            Text(raw!!.take(1200), color = p.muted, fontSize = 11.sp, lineHeight = 16.sp)
                        }
                    }
                }
            }

            // 결과
            if (found.isNotEmpty()) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("불러온 캐릭터", color = p.text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.width(8.dp))
                        Text("${found.size}명", color = p.muted, fontSize = 11.5.sp)
                        Spacer(Modifier.weight(1f))
                        val selectable = found.filter { it.name !in existing }.map { it.name }.toSet()
                        Text(
                            if (picked.size >= selectable.size && selectable.isNotEmpty()) "전체 해제" else "전체 선택",
                            color = p.normal, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                            modifier = Modifier
                                .clickable {
                                    picked = if (picked.size >= selectable.size) emptySet() else selectable
                                }
                                .padding(6.dp)
                        )
                    }
                    Spacer(Modifier.height(9.dp))
                    CardBox {
                        found.forEach { r ->
                            val already = r.name in existing
                            val on = r.name in picked
                            Row(
                                Modifier
                                    .fillMaxWidth()
                                    .clickable(enabled = !already) {
                                        picked = if (on) picked - r.name else picked + r.name
                                    }
                                    .padding(horizontal = 14.dp, vertical = 11.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                CheckSquare(on && !already)
                                Spacer(Modifier.width(10.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(
                                        r.name,
                                        color = if (already) p.muted else p.text,
                                        fontSize = 14.sp, fontWeight = FontWeight.Medium, maxLines = 1
                                    )
                                    Text(
                                        listOfNotNull(
                                            r.world.takeIf { it.isNotBlank() },
                                            r.job.takeIf { it.isNotBlank() },
                                            if (r.level > 0) "Lv.${r.level}" else null
                                        ).joinToString(" · "),
                                        color = p.muted, fontSize = 11.sp, maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                                if (already) Text("추가됨", color = p.muted, fontSize = 11.sp)
                            }
                            Box(Modifier.fillMaxWidth().height(1.dp).background(p.lineSoft))
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    PillButton("선택한 ${picked.size}명 추가", p.gold, {
                        val add = found.filter { it.name in picked && it.name !in existing }
                        if (add.isNotEmpty()) {
                            store.update { st ->
                                st.copy(toons = st.toons + add.map { r ->
                                    Toon(
                                        id = r.name + "@" + r.world + "#" + System.nanoTime(),
                                        name = r.name,
                                        ocid = r.ocid,
                                        world = r.world,
                                        job = r.job,
                                        level = r.level
                                        // 보스는 비워 둡니다. "보스 선택" 또는 "한 번에 편집"에서 고르세요.
                                    )
                                })
                            }
                            onBack()
                        }
                    }, Modifier.fillMaxWidth())
                }
            }

            // 스케줄러 API 실험
            CardBox {
                Column(Modifier.padding(14.dp)) {
                    Text("API 응답 확인", color = p.text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "넥슨 오픈 API에는 “스케줄러 정보 조회”가 있습니다. 인게임 스케줄러에 등록한 주간보스를 " +
                            "그대로 가져올 수 있을지 모릅니다. 아직 정확한 경로를 몰라서, 직접 호출해보고 " +
                            "응답을 확인할 수 있는 화면을 넣어 뒀어요.",
                        color = p.muted, fontSize = 12.sp, lineHeight = 18.sp
                    )
                    Spacer(Modifier.height(10.dp))
                    PillButton("API 응답 확인 열기", p.normal, onApiTool)
                }
            }

            // 수동 추가
            CardBox {
                Column(Modifier.padding(14.dp)) {
                    Text("직접 추가", color = p.text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "API 없이 이름만으로 추가할 수도 있어요. 보스는 추가한 뒤 골라주세요.",
                        color = p.muted, fontSize = 12.sp
                    )
                    Spacer(Modifier.height(10.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.weight(1f)) { KeyField(manual, { manual = it }, "캐릭터 이름") }
                        Spacer(Modifier.width(8.dp))
                        PillButton("추가", p.gold, {
                            val nm = manual.trim()
                            if (nm.isNotEmpty()) {
                                store.update { st ->
                                    st.copy(
                                        toons = st.toons + Toon(
                                            id = nm + "#" + System.nanoTime(),
                                            name = nm
                                        )
                                    )
                                }
                                manual = ""
                                onBack()
                            }
                        })
                    }
                }
            }
        }
    }
}

@Composable
private fun KeyField(value: String, onChange: (String) -> Unit, hint: String = "test_xxxxxxxx…") {
    val p = LocalPalette.current
    Box(
        Modifier
            .fillMaxWidth()
            .border(1.dp, p.line, RoundedCornerShape(9.dp))
            .background(p.panel2, RoundedCornerShape(9.dp))
            .padding(horizontal = 11.dp, vertical = 10.dp)
    ) {
        if (value.isEmpty()) {
            Text(hint, color = p.muted, fontSize = 13.sp)
        }
        BasicTextField(
            value = value,
            onValueChange = onChange,
            singleLine = true,
            textStyle = TextStyle(color = p.text, fontSize = 13.sp),
            cursorBrush = SolidColor(p.gold),
            modifier = Modifier.fillMaxWidth()
        )
    }
}

/* ══════════════════════════════════════════════════════════════
 * API 응답 확인 — 스케줄러 엔드포인트를 찾아내기 위한 화면
 * ══════════════════════════════════════════════════════════════ */

private val CANDIDATE_PATHS = listOf(
    "/maplestory/v1/character/list",
    "/maplestory/v1/scheduler",
    "/maplestory/v1/user/scheduler",
    "/maplestory/v1/character/scheduler"
)

/** 스케줄러 엔드포인트를 찾기 위해 한꺼번에 두드려 볼 후보들 (전부 추측입니다) */
private val PROBE_PATHS = listOf(
    "/maplestory/v1/scheduler",
    "/maplestory/v1/scheduler/list",
    "/maplestory/v1/scheduler/basic",
    "/maplestory/v1/scheduler/boss",
    "/maplestory/v1/user/scheduler",
    "/maplestory/v1/user/scheduler/list",
    "/maplestory/v1/character/scheduler",
    "/maplestory/v1/character/schedule",
    "/maplestory/v1/character/boss",
    "/maplestory/v1/character/weekly-boss"
)

@Composable
private fun ApiToolScreen(store: Store, onBack: () -> Unit) {
    val p = LocalPalette.current
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current

    var path by remember { mutableStateOf(CANDIDATE_PATHS[0]) }
    var loading by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf<String?>(null) }
    var ok by remember { mutableStateOf(false) }
    var body by remember { mutableStateOf("") }
    var probing by remember { mutableStateOf(false) }
    var probe by remember { mutableStateOf<List<Pair<String, String>>>(emptyList()) }

    val key = store.state.apiKey
    val withOcid = store.state.toons.filter { it.ocid.isNotBlank() }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(
                "‹ 뒤로", color = p.text2, fontSize = 14.sp,
                modifier = Modifier.clickable { onBack() }.padding(end = 12.dp)
            )
            Text("API 응답 확인", color = p.text, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            if (body.isNotEmpty()) {
                PillButton("복사", p.gold, { clipboard.setText(AnnotatedString(body)) })
            }
        }
        Box(Modifier.fillMaxWidth().height(1.dp).background(p.line))

        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            CardBox {
                Column(Modifier.padding(14.dp)) {
                    Text("무엇을 하는 화면인가요", color = p.text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "1. 넥슨 오픈 API 문서에서 “스케줄러 정보 조회”를 열어 엔드포인트 경로를 확인합니다.\n" +
                            "2. 그 경로를 아래에 붙여넣고 호출합니다.\n" +
                            "3. 나온 응답을 복사해서 알려주시면, 등록된 주간보스를 자동으로 가져오도록 만들어 드립니다.\n\n" +
                            "아래 후보 경로는 추측이라 대부분 404가 날 겁니다. 문서에 적힌 정확한 경로가 정답입니다.",
                        color = p.muted, fontSize = 12.sp, lineHeight = 19.sp
                    )
                    Spacer(Modifier.height(10.dp))
                    PillButton("넥슨 API 문서 열기", p.text2, {
                        ctx.startActivity(
                            Intent(Intent.ACTION_VIEW, Uri.parse("https://openapi.nexon.com/ko/game/maplestory/"))
                        )
                    })
                }
            }

            CardBox {
                Column(Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("엔드포인트", color = p.text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.weight(1f))
                        Text(
                            if (key.isBlank()) "API 키 없음" else "API 키 저장됨",
                            color = if (key.isBlank()) p.extreme else p.easy, fontSize = 11.sp
                        )
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(NexonApi.HOST, color = p.muted, fontSize = 11.sp)
                    Spacer(Modifier.height(5.dp))
                    KeyField(path, { path = it }, "/maplestory/v1/...")

                    Spacer(Modifier.height(9.dp))
                    Row(
                        Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        CANDIDATE_PATHS.forEach { c ->
                            SegButton(c.removePrefix("/maplestory/v1/"), null, path == c, p.normal) { path = c }
                        }
                    }

                    if (withOcid.isNotEmpty()) {
                        Spacer(Modifier.height(9.dp))
                        Text("ocid 붙이기", color = p.muted, fontSize = 11.sp)
                        Spacer(Modifier.height(5.dp))
                        Row(
                            Modifier.horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            withOcid.forEach { t ->
                                SegButton(t.name, null, false, p.hard) {
                                    val base = path.substringBefore("?")
                                    path = "$base?ocid=${t.ocid}"
                                }
                            }
                        }
                    }

                    Spacer(Modifier.height(12.dp))
                    PillButton(if (probing) "찾는 중…" else "후보 경로 한꺼번에 시도", p.normal, {
                        if (!probing && !loading) {
                            probing = true; probe = emptyList()
                            scope.launch {
                                val ocid = store.state.toons.guildRep()?.ocid.orEmpty()
                                val out = ArrayList<Pair<String, String>>()
                                for (c in PROBE_PATHS) {
                                    val target = if (ocid.isBlank()) c else "$c?ocid=$ocid"
                                    val line = try {
                                        val r = withContext(Dispatchers.IO) { NexonApi.raw(target, key) }
                                        "HTTP ${r.code}"
                                    } catch (e: Exception) {
                                        "실패"
                                    }
                                    out.add(target to line)
                                    probe = out.toList()
                                    delay(250)
                                }
                                probing = false
                            }
                        }
                    }, Modifier.fillMaxWidth())

                    if (probe.isNotEmpty()) {
                        Spacer(Modifier.height(10.dp))
                        Text(
                            "200 이 나온 경로가 정답입니다. 눌러서 위 칸에 넣고 호출해 보세요.",
                            color = p.muted, fontSize = 11.sp
                        )
                        Spacer(Modifier.height(6.dp))
                        probe.forEach { (path0, res) ->
                            val good = res == "HTTP 200"
                            Row(
                                Modifier
                                    .fillMaxWidth()
                                    .clickable { path = path0 }
                                    .padding(vertical = 5.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    path0.removePrefix("/maplestory/v1/").substringBefore("?"),
                                    color = if (good) p.text else p.muted,
                                    fontSize = 11.5.sp,
                                    modifier = Modifier.weight(1f),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    res,
                                    color = if (good) p.easy else p.muted,
                                    fontSize = 11.5.sp,
                                    fontWeight = if (good) FontWeight.Bold else FontWeight.Normal
                                )
                            }
                        }
                    }

                    Spacer(Modifier.height(12.dp))
                    PillButton(if (loading) "호출 중…" else "호출하기", p.gold, {
                        if (!loading) {
                            loading = true; status = null; body = ""
                            scope.launch {
                                try {
                                    val r = withContext(Dispatchers.IO) { NexonApi.raw(path, key) }
                                    ok = r.code == 200
                                    status = "HTTP ${r.code}"
                                    body = NexonApi.pretty(r.body)
                                } catch (e: NexonApi.ApiException) {
                                    ok = false
                                    status = "실패"
                                    body = (e.message ?: "") + (if (e.raw.isBlank()) "" else "\n\n" + e.raw)
                                } catch (e: Exception) {
                                    ok = false
                                    status = "실패"
                                    body = e.message ?: "알 수 없는 오류"
                                } finally {
                                    loading = false
                                }
                            }
                        }
                    }, Modifier.fillMaxWidth())
                }
            }

            status?.let { st ->
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            st,
                            color = if (ok) p.easy else p.extreme,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier
                                .border(1.dp, (if (ok) p.easy else p.extreme).copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                                .padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                        Spacer(Modifier.weight(1f))
                        Text("${body.length}자", color = p.muted, fontSize = 11.sp)
                    }
                    Spacer(Modifier.height(9.dp))
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .border(1.dp, p.line, RoundedCornerShape(11.dp))
                            .background(p.panel2, RoundedCornerShape(11.dp))
                            .padding(12.dp)
                    ) {
                        SelectionContainer {
                            Text(
                                body.take(20000),
                                color = p.text2,
                                fontSize = 11.sp,
                                lineHeight = 16.sp
                            )
                        }
                    }
                    if (body.length > 20000) {
                        Spacer(Modifier.height(6.dp))
                        Text("너무 길어서 앞부분만 표시했습니다. 복사 버튼을 쓰면 전체가 복사됩니다.", color = p.muted, fontSize = 11.sp)
                    }
                }
            }
        }
    }
}

/* ══════════════════════════════════════════════════════════════
 * 한 번에 편집 — 보스 하나를 놓고 캐릭터 전원의 난이도를 찍습니다
 * ══════════════════════════════════════════════════════════════ */

/** 안 함 → 첫 난이도 → … → 마지막 난이도 → 다시 안 함 */
private fun nextTier(boss: Boss, current: String?): String? {
    val names = boss.tiers.map { it.name }
    val i = names.indexOf(current)
    return if (i + 1 >= names.size) null else names[i + 1]
}

@Composable
private fun MatrixScreen(store: Store, onBack: () -> Unit) {
    val p = LocalPalette.current
    val toons = store.state.toons

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(
                "‹ 뒤로", color = p.text2, fontSize = 14.sp,
                modifier = Modifier.clickable { onBack() }.padding(end = 12.dp)
            )
            Column(Modifier.weight(1f)) {
                Text("한 번에 편집", color = p.text, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Text(
                    "칩을 누를 때마다 안 함 → 이지 → 노멀 → 하드 … 순서로 바뀝니다",
                    color = p.muted, fontSize = 11.sp
                )
            }
        }
        Box(Modifier.fillMaxWidth().height(1.dp).background(p.line))

        // 캐릭터별 등록 개수 요약
        Row(
            Modifier
                .fillMaxWidth()
                .background(p.panel2)
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 14.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            toons.forEach { t ->
                val n = t.stat().total
                Text(
                    "${t.name} $n",
                    color = if (n > Bosses.CAP_CHARACTER) p.extreme else p.muted,
                    fontSize = 11.sp,
                    maxLines = 1
                )
            }
        }

        LazyColumn(
            Modifier.weight(1f),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(
                start = 14.dp, end = 14.dp, top = 8.dp, bottom = 28.dp
            )
        ) {
            items(Bosses.all) { boss ->
                Column(Modifier.fillMaxWidth().padding(vertical = 10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(boss.name, color = p.text, fontSize = 13.5.sp, fontWeight = FontWeight.SemiBold)
                        if (boss.monthly) {
                            Spacer(Modifier.width(6.dp))
                            Text("월간", color = p.muted, fontSize = 11.sp)
                        }
                        Spacer(Modifier.weight(1f))
                        val n = toons.count { it.bosses.containsKey(boss.id) }
                        if (n > 0) Text("$n명", color = p.gold, fontSize = 11.sp)
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(
                        Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        toons.forEach { t ->
                            MatrixChip(t.name, t.bosses[boss.id]) {
                                store.updateToon(t.id) { tt ->
                                    val nx = nextTier(boss, tt.bosses[boss.id])
                                    if (nx == null) tt.copy(
                                        bosses = tt.bosses - boss.id,
                                        done = tt.done - boss.id
                                    ) else tt.copy(bosses = tt.bosses + (boss.id to nx))
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    Box(Modifier.fillMaxWidth().height(1.dp).background(p.lineSoft))
                }
            }
        }
    }
}

@Composable
private fun MatrixChip(name: String, tier: String?, onClick: () -> Unit) {
    val p = LocalPalette.current
    val accent = if (tier == null) p.line else p.tier(tier)
    Column(
        Modifier
            .widthIn(min = 76.dp)
            .border(1.dp, accent, RoundedCornerShape(8.dp))
            .background(if (tier == null) p.panel else p.panel3, RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 9.dp, vertical = 7.dp)
    ) {
        Text(
            name,
            color = if (tier == null) p.muted else p.text,
            fontSize = 11.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.widthIn(max = 90.dp)
        )
        Spacer(Modifier.height(3.dp))
        Text(
            tier ?: "안 함",
            color = if (tier == null) p.muted else p.tier(tier),
            fontSize = 12.sp,
            fontWeight = if (tier == null) FontWeight.Normal else FontWeight.SemiBold
        )
    }
}
