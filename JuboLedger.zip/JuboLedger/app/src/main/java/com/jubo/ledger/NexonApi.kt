package com.jubo.ledger

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * 넥슨 오픈 API — 계정 내 캐릭터 목록 조회.
 *
 * 인증은 OAuth(넥슨 ID 로그인)가 아니라 API Key 헤더 방식입니다.
 * 키는 https://openapi.nexon.com 에서 본인이 직접 발급받아야 하며,
 * 그 키를 발급한 넥슨 계정의 캐릭터만 조회됩니다.
 *
 * 응답 스키마가 바뀌어도 버티도록, JSON 트리를 훑어서
 * "character_name" 을 가진 객체를 전부 캐릭터로 인식합니다.
 */
object NexonApi {

    const val HOST = "https://open.api.nexon.com"
    private const val CHARACTER_LIST = "$HOST/maplestory/v1/character/list"
    private const val OCID = "$HOST/maplestory/v1/id"
    private const val SCHEDULER = "$HOST/maplestory/v1/scheduler/character-state"
    private const val TIMEOUT_MS = 15_000

    data class Remote(
        val name: String,
        val ocid: String,
        val world: String,
        val job: String,
        val level: Int
    )

    /** 사용자에게 보여줄 메시지 + 원문(디버그용) */
    class ApiException(message: String, val raw: String) : Exception(message)

    /** 임의의 엔드포인트를 그대로 호출해 응답을 돌려줍니다 (API 응답 확인 화면용). */
    data class RawResult(val code: Int, val body: String)

    fun raw(pathOrUrl: String, apiKey: String): RawResult {
        val key = apiKey.trim()
        if (key.isEmpty()) throw ApiException("API 키를 먼저 입력해 주세요.", "")
        val p = pathOrUrl.trim()
        if (p.isEmpty()) throw ApiException("엔드포인트 경로를 입력해 주세요.", "")
        val url = escapeNonAscii(
            when {
                p.startsWith("http://") || p.startsWith("https://") -> p
                p.startsWith("/") -> HOST + p
                else -> "$HOST/$p"
            }
        )
        val (code, body) = get(url, key)
        return RawResult(code, body)
    }

    /**
     * 한글처럼 ASCII 가 아닌 글자를 %XX 로 바꿉니다.
     * 주소창에 캐릭터 이름을 그대로 적어도 호출되도록 하려는 것입니다.
     * 이미 %XX 로 적혀 있으면 건드리지 않습니다.
     */
    private fun escapeNonAscii(url: String): String {
        if (url.all { it.code < 128 }) return url
        val out = StringBuilder(url.length + 16)
        for (ch in url) {
            if (ch.code < 128) {
                out.append(ch)
            } else {
                for (b in ch.toString().toByteArray(Charsets.UTF_8)) {
                    out.append('%').append(String.format("%02X", b.toInt() and 0xFF))
                }
            }
        }
        return out.toString()
    }

    /** 보기 좋게 들여쓴 JSON. 파싱이 안 되면 원문 그대로. */
    fun pretty(body: String): String = try {
        val t = body.trim()
        if (t.startsWith("[")) JSONArray(t).toString(2) else JSONObject(t).toString(2)
    } catch (e: Exception) {
        body
    }

    /** IO 스레드에서 호출하세요. */
    fun fetchCharacters(apiKey: String): List<Remote> {
        val key = apiKey.trim()
        if (key.isEmpty()) throw ApiException("API 키를 먼저 입력해 주세요.", "")

        val (code, body) = get(CHARACTER_LIST, key)
        if (code != HttpURLConnection.HTTP_OK) {
            throw ApiException(friendlyError(code, body), body)
        }

        val found = parse(body)
        if (found.isEmpty()) {
            throw ApiException(
                "응답은 받았지만 캐릭터를 찾지 못했습니다. 키가 다른 계정의 것이거나, 응답 형식이 바뀌었을 수 있어요.",
                body
            )
        }
        return found
    }

    // ── HTTP ─────────────────────────────────────────────────

    private fun get(urlString: String, apiKey: String): Pair<Int, String> {
        var conn: HttpURLConnection? = null
        try {
            conn = (URL(urlString).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                setRequestProperty("x-nxopen-api-key", apiKey)
                setRequestProperty("Accept", "application/json")
                connectTimeout = TIMEOUT_MS
                readTimeout = TIMEOUT_MS
                instanceFollowRedirects = true
            }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else (conn.errorStream ?: conn.inputStream)
            val text = stream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            return code to text
        } catch (e: ApiException) {
            throw e
        } catch (e: Exception) {
            throw ApiException(
                "넥슨 서버에 연결하지 못했습니다. 네트워크 상태를 확인해 주세요.\n(${e.javaClass.simpleName})",
                e.message ?: ""
            )
        } finally {
            conn?.disconnect()
        }
    }

    private fun friendlyError(code: Int, body: String): String {
        val detail = try {
            JSONObject(body).optJSONObject("error")?.optString("message").orEmpty()
        } catch (e: Exception) {
            ""
        }
        val head = when (code) {
            400 -> "요청이 올바르지 않습니다."
            401, 403 -> "API 키가 유효하지 않습니다. 넥슨 오픈 API 사이트에서 키를 다시 확인해 주세요."
            429 -> "API 호출량을 초과했습니다. 잠시 뒤 다시 시도해 주세요."
            in 500..599 -> "넥슨 서버가 응답하지 않습니다. 점검 중일 수 있어요."
            else -> "요청에 실패했습니다. (HTTP $code)"
        }
        return if (detail.isBlank()) head else "$head\n$detail"
    }

    // ── 파싱 (스키마 변화에 관대하게) ─────────────────────────

    private fun parse(body: String): List<Remote> {
        val out = ArrayList<Remote>()
        val root: Any = try {
            val trimmed = body.trim()
            if (trimmed.startsWith("[")) JSONArray(trimmed) else JSONObject(trimmed)
        } catch (e: Exception) {
            return emptyList()
        }
        collect(root, out)

        // 이름+월드 기준 중복 제거, 레벨 높은 순
        return out
            .distinctBy { it.name + "@" + it.world }
            .sortedWith(compareByDescending<Remote> { it.level }.thenBy { it.name })
    }

    private fun collect(node: Any?, out: MutableList<Remote>) {
        when (node) {
            is JSONObject -> {
                val name = node.optString("character_name", "").trim()
                if (name.isNotEmpty()) {
                    out.add(
                        Remote(
                            name = name,
                            ocid = node.optString("ocid", "").trim(),
                            world = node.optString("world_name", "").trim(),
                            job = node.optString("character_class", "").trim(),
                            level = node.optInt("character_level", 0)
                        )
                    )
                }
                val keys = node.keys()
                while (keys.hasNext()) collect(node.opt(keys.next()), out)
            }

            is JSONArray -> {
                for (i in 0 until node.length()) collect(node.opt(i), out)
            }
        }
    }
}


/* ══════════════════════════════════════════════════════════════
 * 인게임 스케줄러 연동
 * ══════════════════════════════════════════════════════════════ */

/** 스케줄러에 들어 있는 보스 한 줄 */
data class SchedulerBoss(
    val name: String,
    /** 이지 / 노멀 / 하드 / 카오스 / 익스트림 */
    val difficulty: String,
    /** bossDaily / bossWeekly / bossMonthly */
    val cycle: String,
    val registered: Boolean,
    val completed: Boolean,
    /** 스케줄러가 보여주는 순서 (list_order_no). 작을수록 위. */
    val order: Int = 0
)

data class SchedulerState(
    val characterName: String,
    val world: String,
    val job: String,
    val level: Int,
    /** API 기준 시각 문자열 */
    val date: String,
    val bosses: List<SchedulerBoss>,
    val weeklyClearCount: Int,
    val weeklyClearLimit: Int
)

/** 캐릭터 이름 → ocid */
fun NexonApi.fetchOcid(apiKey: String, characterName: String): String {
    val encoded = URLEncoder.encode(characterName, "UTF-8")
    val r = NexonApi.raw("/maplestory/v1/id?character_name=$encoded", apiKey)
    if (r.code != 200) throw NexonApi.ApiException(
        "‘$characterName’의 ocid를 가져오지 못했습니다. (HTTP ${r.code})", r.body
    )
    val id = try { JSONObject(r.body).optString("ocid", "") } catch (e: Exception) { "" }
    if (id.isBlank()) throw NexonApi.ApiException("‘$characterName’의 ocid가 응답에 없습니다.", r.body)
    return id
}

/**
 * ocid → 전투력.
 *
 * 캐릭터 종합 능력치(final_stat) 안에 "전투력" 항목이 들어 있습니다.
 * 응답 모양이 바뀌어도 버티도록, 이름에 "전투력" 이 들어간 항목을 찾아서 씁니다.
 * 못 찾으면 0 을 돌려주고, 그러면 앱은 레벨로 판단합니다.
 */
fun NexonApi.fetchCombatPower(apiKey: String, ocid: String): Long {
    val r = NexonApi.raw("/maplestory/v1/character/stat?ocid=$ocid", apiKey)
    if (r.code != 200) return 0L
    return try {
        val arr = JSONObject(r.body).optJSONArray("final_stat") ?: return 0L
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            if (!o.optString("stat_name", "").contains("전투력")) continue
            val v = o.optString("stat_value", "").replace(",", "").trim()
            return v.toLongOrNull() ?: 0L
        }
        0L
    } catch (e: Exception) {
        0L
    }
}

/** ocid → 인게임 스케줄러 상태 */
fun NexonApi.fetchSchedulerState(apiKey: String, ocid: String): SchedulerState {
    val r = NexonApi.raw("/maplestory/v1/scheduler/character-state?ocid=$ocid", apiKey)
    if (r.code != 200) throw NexonApi.ApiException(
        "스케줄러 정보를 가져오지 못했습니다. (HTTP ${r.code})", r.body
    )
    val o = JSONObject(r.body)

    val list = ArrayList<SchedulerBoss>()
    val arr = o.optJSONArray("boss_contents") ?: JSONArray()
    for (i in 0 until arr.length()) {
        val b = arr.optJSONObject(i) ?: continue
        list.add(
            SchedulerBoss(
                name = b.optString("content_name", "").trim(),
                difficulty = difficultyKo(b.optString("difficulty", "")),
                cycle = b.optString("cycle", ""),
                registered = flagOf(b, "registration_flag"),
                completed = flagOf(b, "complete_flag"),
                order = b.optInt("list_order_no", 0)
            )
        )
    }

    return SchedulerState(
        characterName = o.optString("character_name", ""),
        world = o.optString("world_name", ""),
        job = o.optString("character_class", ""),
        level = o.optInt("character_level", 0),
        date = o.optString("date", ""),
        bosses = list,
        weeklyClearCount = o.optInt("weekly_boss_clear_count", 0),
        weeklyClearLimit = o.optInt("weekly_boss_clear_limit_count", 0)
    )
}

/**
 * 참/거짓 값을 너그럽게 읽습니다.
 * 넥슨 응답이 항목마다 "true" 문자열이기도 하고 true 불린이기도 해서,
 * 어느 쪽이 와도 같게 다룹니다. (1 / Y 도 참으로 봅니다)
 */
private fun flagOf(o: JSONObject, key: String): Boolean {
    if (o.optBoolean(key, false)) return true
    val s = o.optString(key, "").trim().lowercase()
    return s == "true" || s == "1" || s == "y" || s == "yes"
}

private fun difficultyKo(raw: String): String = when (raw.lowercase()) {
    "easy" -> "이지"
    "normal" -> "노멀"
    "hard" -> "하드"
    "chaos" -> "카오스"
    "extreme" -> "익스트림"
    else -> raw
}

/**
 * 스케줄러 상태를 캐릭터에 반영합니다.
 *
 * 난이도를 고르는 규칙:
 *   1) 클리어한 난이도가 있으면 그것 — 실제로 잡은 게 진실이므로
 *   2) 없으면 스케줄러에 등록한 난이도
 *   3) 둘 다 없으면 이 보스는 넣지 않음
 *
 * 매칭은 최대한 너그럽게 합니다.
 *   - 이름은 공백을 빼고 비교합니다. ("검은 마법사" / "검은마법사")
 *   - 주기(cycle)는 일일 보스만 빼고 다 받습니다. 월간 보스의 cycle 값이
 *     응답마다 다르게 오더라도 검은 마법사를 놓치지 않기 위해서입니다.
 *   - 난이도 이름이 우리 표에 없으면 보스를 버리지 않고, 원래 쓰던 난이도나
 *     첫 난이도로 대신 넣습니다. 잡은 표시를 잃는 것보다 낫습니다.
 *
 * 체크는 더하기만 합니다. 손으로 켠 체크를 동기화가 끄지 않습니다.
 */
fun applyScheduler(toon: Toon, state: SchedulerState): Toon {
    fun key(s: String) = s.replace(" ", "").trim()

    val byName = state.bosses
        .filter { !it.cycle.lowercase().contains("daily") }
        .groupBy { key(it.name) }

    val bosses = LinkedHashMap<String, String>()
    val done = HashSet<String>()

    for (boss in Bosses.all) {
        val rows = byName[key(boss.name)] ?: continue

        // 같은 보스에 여러 난이도가 걸려 있으면 높은 난이도를 씁니다.
        fun rank(r: SchedulerBoss) = boss.tiers.indexOfFirst { key(it.name) == key(r.difficulty) }

        // 잡았으면 '잡은 난이도', 아직이면 '스케줄러에 등록한 난이도'.
        // (노멀로 등록해 두고 이지를 잡는 경우가 있어서, 실제 클리어가 항상 우선입니다)
        val cleared = rows.filter { it.completed }.maxByOrNull { rank(it) }
        val chosen = cleared ?: rows.filter { it.registered }.maxByOrNull { rank(it) } ?: continue
        val tier = boss.tiers.firstOrNull { key(it.name) == key(chosen.difficulty) }?.name
            ?: toon.bosses[boss.id]
            ?: boss.tiers.first().name
        bosses[boss.id] = tier
        if (cleared != null) done.add(boss.id)
    }

    // 손으로 넣은 보스는 동기화가 빼지 않습니다.
    // 스케줄러가 모르는 보스(앱에서 직접 추가한 것)를 지워버리면
    // 그 보스에 해 둔 체크까지 같이 사라집니다. 그래서 합집합으로 둡니다.
    // 빼고 싶으면 '보스 선택'에서 직접 빼면 됩니다.
    val merged = LinkedHashMap(bosses)
    for ((id, tier) in toon.bosses) if (!merged.containsKey(id)) merged[id] = tier

    // 손으로 켠 체크도 동기화가 끄지 않습니다.
    // API 가 "아직 안 잡음" 이라고 해도 사용자가 이미 체크했으면 그대로 둡니다.
    // (게임 데이터가 아직 갱신되지 않은 경우가 있어서 — 특히 검은 마법사 같은 월간 보스)
    // 체크가 풀리는 건 오직 주간·월간 초기화 때뿐입니다.
    val keptManual = toon.done.filter { merged.containsKey(it) }

    return toon.copy(
        bosses = merged,
        done = done + keptManual,
        world = state.world.ifBlank { toon.world },
        job = state.job.ifBlank { toon.job },
        level = if (state.level > 0) state.level else toon.level,
        syncedAt = System.currentTimeMillis()
    )
}
