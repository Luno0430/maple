package com.jubo.ledger

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * 넥슨 오픈 API — 계정 내 캐릭터 목록 조회.
 *
 * 인증은 OAuth(넥슨 ID 로그인)가 아니라 API Key 헤더 방식입니다.
 * 키는 https://openapi.nexon.com 에서 본인이 직접 발급받아야 하며,
 * 그 키를 발급한 넥슨 계정의 캐릭터만 조회됩니다.
 *
 * 응답 스키마가 바뀌어도 버티도록, JSON 트리를 훑어서
 * "character_name" 을 가진 객체를 전부 캐릭터로 인식합니다.
 */
object NexonApi {

    const val HOST = "https://open.api.nexon.com"
    private const val CHARACTER_LIST = "$HOST/maplestory/v1/character/list"
    private const val TIMEOUT_MS = 15_000

    data class Remote(
        val name: String,
        val ocid: String,
        val world: String,
        val job: String,
        val level: Int
    )

    /** 사용자에게 보여줄 메시지 + 원문(디버그용) */
    class ApiException(message: String, val raw: String) : Exception(message)

    /** 임의의 엔드포인트를 그대로 호출해 응답을 돌려줍니다 (API 응답 확인 화면용). */
    data class RawResult(val code: Int, val body: String)

    fun raw(pathOrUrl: String, apiKey: String): RawResult {
        val key = apiKey.trim()
        if (key.isEmpty()) throw ApiException("API 키를 먼저 입력해 주세요.", "")
        val p = pathOrUrl.trim()
        if (p.isEmpty()) throw ApiException("엔드포인트 경로를 입력해 주세요.", "")
        val url = when {
            p.startsWith("http://") || p.startsWith("https://") -> p
            p.startsWith("/") -> HOST + p
            else -> "$HOST/$p"
        }
        val (code, body) = get(url, key)
        return RawResult(code, body)
    }

    /** 보기 좋게 들여쓴 JSON. 파싱이 안 되면 원문 그대로. */
    fun pretty(body: String): String = try {
        val t = body.trim()
        if (t.startsWith("[")) JSONArray(t).toString(2) else JSONObject(t).toString(2)
    } catch (e: Exception) {
        body
    }

    /** IO 스레드에서 호출하세요. */
    fun fetchCharacters(apiKey: String): List<Remote> {
        val key = apiKey.trim()
        if (key.isEmpty()) throw ApiException("API 키를 먼저 입력해 주세요.", "")

        val (code, body) = get(CHARACTER_LIST, key)
        if (code != HttpURLConnection.HTTP_OK) {
            throw ApiException(friendlyError(code, body), body)
        }

        val found = parse(body)
        if (found.isEmpty()) {
            throw ApiException(
                "응답은 받았지만 캐릭터를 찾지 못했습니다. 키가 다른 계정의 것이거나, 응답 형식이 바뀌었을 수 있어요.",
                body
            )
        }
        return found
    }

    // ── HTTP ─────────────────────────────────────────────────

    private fun get(urlString: String, apiKey: String): Pair<Int, String> {
        var conn: HttpURLConnection? = null
        try {
            conn = (URL(urlString).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                setRequestProperty("x-nxopen-api-key", apiKey)
                setRequestProperty("Accept", "application/json")
                connectTimeout = TIMEOUT_MS
                readTimeout = TIMEOUT_MS
                instanceFollowRedirects = true
            }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else (conn.errorStream ?: conn.inputStream)
            val text = stream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            return code to text
        } catch (e: ApiException) {
            throw e
        } catch (e: Exception) {
            throw ApiException(
                "넥슨 서버에 연결하지 못했습니다. 네트워크 상태를 확인해 주세요.\n(${e.javaClass.simpleName})",
                e.message ?: ""
            )
        } finally {
            conn?.disconnect()
        }
    }

    private fun friendlyError(code: Int, body: String): String {
        val detail = try {
            JSONObject(body).optJSONObject("error")?.optString("message").orEmpty()
        } catch (e: Exception) {
            ""
        }
        val head = when (code) {
            400 -> "요청이 올바르지 않습니다."
            401, 403 -> "API 키가 유효하지 않습니다. 넥슨 오픈 API 사이트에서 키를 다시 확인해 주세요."
            429 -> "API 호출량을 초과했습니다. 잠시 뒤 다시 시도해 주세요."
            in 500..599 -> "넥슨 서버가 응답하지 않습니다. 점검 중일 수 있어요."
            else -> "요청에 실패했습니다. (HTTP $code)"
        }
        return if (detail.isBlank()) head else "$head\n$detail"
    }

    // ── 파싱 (스키마 변화에 관대하게) ─────────────────────────

    private fun parse(body: String): List<Remote> {
        val out = ArrayList<Remote>()
        val root: Any = try {
            val trimmed = body.trim()
            if (trimmed.startsWith("[")) JSONArray(trimmed) else JSONObject(trimmed)
        } catch (e: Exception) {
            return emptyList()
        }
        collect(root, out)

        // 이름+월드 기준 중복 제거, 레벨 높은 순
        return out
            .distinctBy { it.name + "@" + it.world }
            .sortedWith(compareByDescending<Remote> { it.level }.thenBy { it.name })
    }

    private fun collect(node: Any?, out: MutableList<Remote>) {
        when (node) {
            is JSONObject -> {
                val name = node.optString("character_name", "").trim()
                if (name.isNotEmpty()) {
                    out.add(
                        Remote(
                            name = name,
                            ocid = node.optString("ocid", "").trim(),
                            world = node.optString("world_name", "").trim(),
                            job = node.optString("character_class", "").trim(),
                            level = node.optInt("character_level", 0)
                        )
                    )
                }
                val keys = node.keys()
                while (keys.hasNext()) collect(node.opt(keys.next()), out)
            }

            is JSONArray -> {
                for (i in 0 until node.length()) collect(node.opt(i), out)
            }
        }
    }
}
