package com.jubo.ledger

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

/**
 * 메이플 색감으로 잡은 팔레트.
 *
 *  - accent : 단풍 주황. 브랜드와 누를 수 있는 것들
 *  - gold   : 메소. 숫자와 완료 표시에만 씁니다
 *  - 난이도 : 게임 안 난이도 색을 그대로 (이지 청록 / 노멀 파랑 / 하드 보라 / 카오스 주황 / 익스 빨강)
 */
data class Palette(
    val ground: Color,
    val panel: Color,
    val panel2: Color,
    val panel3: Color,
    val line: Color,
    val lineSoft: Color,
    val text: Color,
    val text2: Color,
    val muted: Color,
    val accent: Color,
    val accentWash: Color,
    val gold: Color,
    val goldWash: Color,
    val checkInk: Color,
    val easy: Color,
    val normal: Color,
    val hard: Color,
    val chaos: Color,
    val extreme: Color
) {
    fun tier(name: String): Color = when (name) {
        "이지" -> easy
        "노멀" -> normal
        "하드" -> hard
        "카오스" -> chaos
        "익스트림" -> extreme
        else -> muted
    }
}

/** 낮 — 메이플 UI 특유의 따뜻한 양피지 톤 */
val LightPalette = Palette(
    ground = Color(0xFFFFF6EA),
    panel = Color(0xFFFFFFFF),
    panel2 = Color(0xFFFFF1DE),
    panel3 = Color(0xFFFFE1BE),
    line = Color(0xFFEFD3AE),
    lineSoft = Color(0xFFF7E6CE),
    text = Color(0xFF2A1D10),
    text2 = Color(0xFF5C4632),
    muted = Color(0xFF917A5D),
    accent = Color(0xFFE25C0B),
    accentWash = Color(0xFFFFE7D2),
    gold = Color(0xFFB57200),
    goldWash = Color(0xFFFFF0CC),
    checkInk = Color(0xFFFFFFFF),
    easy = Color(0xFF0E9E85),
    normal = Color(0xFF2166D8),
    hard = Color(0xFF7B37D6),
    chaos = Color(0xFFD9700A),
    extreme = Color(0xFFD22C2C)
)

/** 밤 — 메이플 밤하늘 같은 짙은 남색 위에 단풍 주황 */
val DarkPalette = Palette(
    ground = Color(0xFF121A30),
    panel = Color(0xFF1C2745),
    panel2 = Color(0xFF243256),
    panel3 = Color(0xFF32406B),
    line = Color(0xFF3B4B7A),
    lineSoft = Color(0xFF2A3760),
    text = Color(0xFFF3F6FF),
    text2 = Color(0xFFC7D2F0),
    muted = Color(0xFF8E9BC4),
    accent = Color(0xFFFF9243),
    accentWash = Color(0xFF3D2712),
    gold = Color(0xFFFFC83D),
    goldWash = Color(0xFF3B2F10),
    checkInk = Color(0xFF221708),
    easy = Color(0xFF3FE3C4),
    normal = Color(0xFF6DB2FF),
    hard = Color(0xFFC08BFF),
    chaos = Color(0xFFFFAB4D),
    extreme = Color(0xFFFF6F6F)
)

val LocalPalette = staticCompositionLocalOf { DarkPalette }

@Composable
fun JuboTheme(
    dark: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val palette = if (dark) DarkPalette else LightPalette
    val scheme = if (dark) {
        darkColorScheme(
            primary = palette.accent,
            background = palette.ground,
            surface = palette.panel,
            onBackground = palette.text,
            onSurface = palette.text
        )
    } else {
        lightColorScheme(
            primary = palette.accent,
            background = palette.ground,
            surface = palette.panel,
            onBackground = palette.text,
            onSurface = palette.text
        )
    }
    CompositionLocalProvider(LocalPalette provides palette) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}
