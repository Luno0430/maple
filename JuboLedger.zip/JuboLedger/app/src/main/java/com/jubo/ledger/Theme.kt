package com.jubo.ledger

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

/**
 * 어두운 차콜 위에 단풍 주황 하나로 끌고 가는 팔레트.
 *
 *  accent : 주황. 진행도·강조·누를 수 있는 것
 *  gold   : 메소 숫자
 *  난이도 : 이지 청록 / 노멀 파랑 / 하드 보라 / 카오스 주황 / 익스 빨강
 */
data class Palette(
    val ground: Color,
    val panel: Color,
    val panel2: Color,
    val panel3: Color,
    val line: Color,
    val lineSoft: Color,
    val text: Color,
    val text2: Color,
    val muted: Color,
    val accent: Color,
    val accentDim: Color,
    val accentWash: Color,
    val gold: Color,
    val goldWash: Color,
    val checkInk: Color,
    val easy: Color,
    val normal: Color,
    val hard: Color,
    val chaos: Color,
    val extreme: Color,
    /**
     * 캐릭터를 구분하는 색. 등록 순서대로 고정 배정하며 순위로 다시 칠하지 않습니다.
     * 색맹 판별과 배경 대비를 검증한 8색이고, 9번째부터는 "기타"로 묶습니다.
     */
    val series: List<Color>
) {
    fun tier(name: String): Color = when (name) {
        "이지" -> easy
        "노멀" -> normal
        "하드" -> hard
        "카오스" -> chaos
        "익스트림" -> extreme
        else -> muted
    }
}

val DarkPalette = Palette(
    ground = Color(0xFF111113),
    panel = Color(0xFF1B1B1F),
    panel2 = Color(0xFF232329),
    panel3 = Color(0xFF2E2E36),
    line = Color(0xFF34343D),
    lineSoft = Color(0xFF26262C),
    text = Color(0xFFF6F6F8),
    text2 = Color(0xFFC6C6CE),
    muted = Color(0xFF8A8A95),
    accent = Color(0xFFFF7A2F),
    accentDim = Color(0xFF8A4520),
    accentWash = Color(0xFF2A1810),
    gold = Color(0xFFFFB93D),
    goldWash = Color(0xFF2B2211),
    checkInk = Color(0xFF17110A),
    easy = Color(0xFF33D6B8),
    normal = Color(0xFF57A8FF),
    hard = Color(0xFFB98CFF),
    chaos = Color(0xFFFF9F45),
    extreme = Color(0xFFFF6B6B),
    series = listOf(
        Color(0xFF3987E5), Color(0xFFD95926), Color(0xFF199E70), Color(0xFFC98500),
        Color(0xFFD55181), Color(0xFF008300), Color(0xFF9085E9), Color(0xFFE66767)
    )
)

val LightPalette = Palette(
    ground = Color(0xFFF6F5F3),
    panel = Color(0xFFFFFFFF),
    panel2 = Color(0xFFF0EFEC),
    panel3 = Color(0xFFE4E2DE),
    line = Color(0xFFDCDAD5),
    lineSoft = Color(0xFFEBE9E5),
    text = Color(0xFF1A1A1D),
    text2 = Color(0xFF4B4B52),
    muted = Color(0xFF7B7B84),
    accent = Color(0xFFDE5F14),
    accentDim = Color(0xFFF3B48E),
    accentWash = Color(0xFFFDEDE2),
    gold = Color(0xFFB07600),
    goldWash = Color(0xFFFCF1D9),
    checkInk = Color(0xFFFFFFFF),
    easy = Color(0xFF0E9A82),
    normal = Color(0xFF2569D8),
    hard = Color(0xFF7B3BD4),
    chaos = Color(0xFFD3700B),
    extreme = Color(0xFFD03434),
    series = listOf(
        Color(0xFF2A78D6), Color(0xFFEB6834), Color(0xFF1BAF7A), Color(0xFFEDA100),
        Color(0xFFE87BA4), Color(0xFF008300), Color(0xFF4A3AA7), Color(0xFFE34948)
    )
)

val LocalPalette = staticCompositionLocalOf { DarkPalette }

@Composable
fun JuboTheme(
    dark: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val palette = if (dark) DarkPalette else LightPalette
    val scheme = if (dark) {
        darkColorScheme(
            primary = palette.accent,
            background = palette.ground,
            surface = palette.panel,
            onBackground = palette.text,
            onSurface = palette.text
        )
    } else {
        lightColorScheme(
            primary = palette.accent,
            background = palette.ground,
            surface = palette.panel,
            onBackground = palette.text,
            onSurface = palette.text
        )
    }
    CompositionLocalProvider(LocalPalette provides palette) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}
