package com.jubo.ledger

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

data class Palette(
    val ground: Color,
    val panel: Color,
    val panel2: Color,
    val panel3: Color,
    val line: Color,
    val lineSoft: Color,
    val text: Color,
    val text2: Color,
    val muted: Color,
    val gold: Color,
    val goldWash: Color,
    val checkInk: Color,
    val easy: Color,
    val normal: Color,
    val hard: Color,
    val chaos: Color,
    val extreme: Color
) {
    /** 난이도 이름 → 색 */
    fun tier(name: String): Color = when (name) {
        "이지" -> easy
        "노멀" -> normal
        "하드" -> hard
        "카오스" -> chaos
        "익스트림" -> extreme
        else -> muted
    }
}

val LightPalette = Palette(
    ground = Color(0xFFF3F1F7),
    panel = Color(0xFFFFFFFF),
    panel2 = Color(0xFFEBE8F2),
    panel3 = Color(0xFFE1DDEC),
    line = Color(0xFFDAD5E6),
    lineSoft = Color(0xFFE7E3F0),
    text = Color(0xFF1A1725),
    text2 = Color(0xFF413B57),
    muted = Color(0xFF6E6889),
    gold = Color(0xFF9A6400),
    goldWash = Color(0xFFF7EDD6),
    checkInk = Color(0xFFFFFFFF),
    easy = Color(0xFF0E8E7B),
    normal = Color(0xFF2B62CC),
    hard = Color(0xFF6C41C9),
    chaos = Color(0xFFB45B08),
    extreme = Color(0xFFBC3129)
)

val DarkPalette = Palette(
    ground = Color(0xFF141220),
    panel = Color(0xFF1E1B2C),
    panel2 = Color(0xFF272337),
    panel3 = Color(0xFF322C46),
    line = Color(0xFF3A3350),
    lineSoft = Color(0xFF2C2740),
    text = Color(0xFFEDE9F7),
    text2 = Color(0xFFC6BFDC),
    muted = Color(0xFF948DAC),
    gold = Color(0xFFF0B429),
    goldWash = Color(0xFF33280F),
    checkInk = Color(0xFF1A1725),
    easy = Color(0xFF3FD9BC),
    normal = Color(0xFF78ADFF),
    hard = Color(0xFFB48CFF),
    chaos = Color(0xFFFFA94D),
    extreme = Color(0xFFFF7062)
)

val LocalPalette = staticCompositionLocalOf { LightPalette }

@Composable
fun JuboTheme(
    dark: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val palette = if (dark) DarkPalette else LightPalette
    val scheme = if (dark) {
        darkColorScheme(
            primary = palette.gold,
            background = palette.ground,
            surface = palette.panel,
            onBackground = palette.text,
            onSurface = palette.text
        )
    } else {
        lightColorScheme(
            primary = palette.gold,
            background = palette.ground,
            surface = palette.panel,
            onBackground = palette.text,
            onSurface = palette.text
        )
    }
    CompositionLocalProvider(LocalPalette provides palette) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}
