package com.jubo.ledger

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import java.time.DayOfWeek
import java.time.ZonedDateTime

/*
 * 휴대폰 알림.
 *
 * 서버는 쓰지 않습니다. 안드로이드의 AlarmManager 로 다음 알림 시각을 하나 예약해 두고,
 * 그 시각이 되면 AlarmReceiver 가 깨어나 저장된 기록을 읽어 알림을 띄우고
 * 곧바로 다음 주 같은 시각을 다시 예약합니다. 앱이 꺼져 있어도 동작합니다.
 *
 * 알림은 두 가지입니다.
 *   1) 수요일 저녁 — 아직 안 잡은 보스가 얼마나 남았는지
 *   2) 목요일 아침 — 지난주 수익과 그 전 주 대비 증감
 */

object Notify {

    const val CHANNEL = "jubo_weekly"

    const val ACTION_DEADLINE = "com.jubo.ledger.action.DEADLINE"
    const val ACTION_WEEKLY = "com.jubo.ledger.action.WEEKLY"

    private const val ID_DEADLINE = 1001
    private const val ID_WEEKLY = 1002

    private fun manager(context: Context): NotificationManager? =
        context.getSystemService(NotificationManager::class.java)

    private fun ensureChannel(context: Context) {
        val nm = manager(context) ?: return
        val ch = NotificationChannel(CHANNEL, "주간 숙제 알림", NotificationManager.IMPORTANCE_DEFAULT)
        ch.description = "마감 임박과 주간 결산을 알려줍니다."
        nm.createNotificationChannel(ch)
    }

    fun show(context: Context, id: Int, title: String, body: String) {
        ensureChannel(context)
        val nm = manager(context) ?: return
        val open = PendingIntent.getActivity(
            context,
            0,
            Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(context, CHANNEL)
            .setSmallIcon(R.drawable.ic_notify)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(Notification.BigTextStyle().bigText(body))
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        nm.notify(id, n)
    }

    fun showDeadline(context: Context, s: AppState) {
        val t = deadlineText(s)
        show(context, ID_DEADLINE, t.first, t.second)
    }

    fun showWeekly(context: Context, s: AppState) {
        val t = weeklyText(s)
        show(context, ID_WEEKLY, t.first, t.second)
    }
}

/* ──────────────────────────────────────────────────────────────
 * 알림 문구
 * ────────────────────────────────────────────────────────────── */

/** 수요일 저녁 — 아직 남은 숙제 */
fun deadlineText(s: AppState): Pair<String, String> {
    val t = s.toons.totals(s.priceOverrides)
    val left = t.weeklyTotal - t.weeklyDone
    val leftMeso = (t.weeklyTarget - t.weeklyEarned).coerceAtLeast(0L)
    val guild = listOfNotNull(
        if (!s.guildFlag) "플래그 레이스" else null,
        if (!s.guildWater) "지하 수로" else null
    )

    if (left <= 0 && guild.isEmpty()) {
        return "이번 주 숙제 끝" to "다 돌았습니다. 내일 0시에 초기화돼요."
    }

    // 남은 것만 한 줄씩. 끝낸 항목은 아예 빼서 목록이 짧아지는 게 보이도록.
    val lines = ArrayList<String>(3)
    if (left > 0) lines.add("보스 ${left}개")
    if (guild.size == 2) lines.add("플래그/수로")
    else if (guild.size == 1) lines.add(guild[0])
    if (leftMeso > 0L) lines.add("남은 메소 - " + meso(leftMeso))

    return "내일 0시에 초기화됩니다" to lines.joinToString("\n")
}

/** 목요일 아침 — 지난주 결산 */
fun weeklyText(s: AppState): Pair<String, String> {
    val thisWeek = Dates.weekStart(Dates.today())
    val last = thisWeek.minusDays(7)
    val prev = thisWeek.minusDays(14)

    val earned = s.log.sumBetween(last, thisWeek)
    val before = s.log.sumBetween(prev, last)

    val cleared = s.log.count { e ->
        val d = Dates.parse(e.date)
        d != null && !d.isBefore(last) && d.isBefore(thisWeek) &&
            Bosses.byId[e.bossId]?.monthly == false
    }
    val total = s.toons.totals(s.priceOverrides).weeklyTotal

    val diff = earned - before
    val compare = when {
        before <= 0L && earned <= 0L -> "지난주 기록이 없어요."
        before <= 0L -> "비교는 다음 주부터 나옵니다."
        diff > 0L -> "그 전 주보다 " + meso(diff) + " 더 벌었어요."
        diff < 0L -> "그 전 주보다 " + meso(-diff) + " 덜 벌었어요."
        else -> "그 전 주와 똑같이 벌었어요."
    }

    val done = if (total > 0) "${cleared}/${total} 완료" else "${cleared}개 클리어"
    val body = "지난주 " + meso(earned) + " · " + done + "\n" + compare
    return "주간보스가 초기화됐습니다" to body
}

/* ──────────────────────────────────────────────────────────────
 * 예약
 * ────────────────────────────────────────────────────────────── */

object Alarms {

    private const val REQ_DEADLINE = 2001
    private const val REQ_WEEKLY = 2002

    /** 창을 15분 두어 '정확한 알람' 권한 없이도 동작하게 합니다. */
    private const val WINDOW_MS = 15L * 60L * 1000L

    fun schedule(context: Context, s: AppState) {
        val am = context.getSystemService(AlarmManager::class.java) ?: return
        one(context, am, REQ_DEADLINE, Notify.ACTION_DEADLINE, s.notifyDeadline, DayOfWeek.WEDNESDAY, s.deadlineHour, s.deadlineMin)
        one(context, am, REQ_WEEKLY, Notify.ACTION_WEEKLY, s.notifyWeekly, DayOfWeek.THURSDAY, s.weeklyHour, s.weeklyMin)
    }

    private fun one(
        context: Context,
        am: AlarmManager,
        req: Int,
        action: String,
        on: Boolean,
        day: DayOfWeek,
        hour: Int,
        minute: Int
    ) {
        val intent = Intent(context, AlarmReceiver::class.java)
        intent.action = action
        val pi = PendingIntent.getBroadcast(
            context, req, intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        am.cancel(pi)
        if (!on) return
        am.setWindow(AlarmManager.RTC_WAKEUP, nextAt(day, hour, minute), WINDOW_MS, pi)
    }

    /** 다음에 올 '그 요일 그 시각' (한국 시간). 이미 지났으면 다음 주. */
    fun nextAt(day: DayOfWeek, hour: Int, minute: Int): Long {
        val now = ZonedDateTime.now(Dates.KST)
        var t = now.withHour(hour).withMinute(minute).withSecond(0).withNano(0)
        val ahead = ((day.value - t.dayOfWeek.value) % 7 + 7) % 7
        t = t.plusDays(ahead.toLong())
        if (!t.isAfter(now)) t = t.plusDays(7)
        return t.toInstant().toEpochMilli()
    }

    /** "목요일 오전 9:00" */
    fun label(day: String, hour: Int, minute: Int): String {
        val ampm = if (hour < 12) "오전" else "오후"
        var h = hour % 12
        if (h == 0) h = 12
        return day + " " + ampm + " " + h.toString() + ":" + (if (minute < 10) "0" else "") + minute.toString()
    }
}

/** 예약한 시각이 되면 깨어납니다. 부팅 직후에도 한 번 불려서 예약을 되살립니다. */
class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val store = Store(context.applicationContext)
        when (intent.action) {
            Notify.ACTION_DEADLINE -> Notify.showDeadline(context, store.state)
            Notify.ACTION_WEEKLY -> Notify.showWeekly(context, store.state)
        }
        // 이번 알림을 쓰고 나면 다음 주 같은 시각을 다시 예약합니다.
        Alarms.schedule(context, store.state)
    }
}
