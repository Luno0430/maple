package com.jubo.ledger

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject

/**
 * 앱 상태를 SharedPreferences 에 JSON 으로 저장합니다.
 * 외부 라이브러리 없이 org.json 만 사용합니다.
 */
class Store(context: Context) {

    private val prefs = context.applicationContext
        .getSharedPreferences("jubo_ledger", Context.MODE_PRIVATE)

    var state by mutableStateOf(applyResets(load()))
        private set

    init {
        persist()
    }

    fun update(block: (AppState) -> AppState) {
        val next = block(state)
        if (next !== state) {
            state = next
            persist()
        }
    }

    /** 초기화 시각이 지났으면 체크를 비웁니다. 1초마다 호출해도 안전합니다. */
    fun refreshResets() {
        val next = applyResets(state)
        if (next !== state) {
            state = next
            persist()
        }
    }

    fun updateToon(id: String, block: (Toon) -> Toon) = update { s ->
        s.copy(toons = s.toons.map { if (it.id == id) block(it) else it })
    }

    fun toggleAutoSync() = update { it.copy(autoSync = !it.autoSync) }

    /** 보스별 파티 인원 순환: 1 → 2 → … → maxParty → 1 */
    fun cycleParty(toonId: String, bossId: String, maxParty: Int) = updateToon(toonId) { t ->
        val next = t.partyOf(bossId) + 1
        val v = if (next > maxParty) 1 else next
        t.copy(party = if (v <= 1) t.party - bossId else t.party + (bossId to v))
    }

    /** 결정석 가격 직접 수정 (만 메소). 0 이하면 되돌립니다. */
    fun setPrice(bossId: String, tier: String, manMeso: Long) = update { s ->
        val k = priceKey(bossId, tier)
        s.copy(priceOverrides = if (manMeso <= 0L) s.priceOverrides - k else s.priceOverrides + (k to manMeso))
    }

    fun toggleFlag() = update { it.copy(guildFlag = !it.guildFlag) }
    fun toggleWater() = update { it.copy(guildWater = !it.guildWater) }

    // ── 초기화 ────────────────────────────────────────────────

    private fun applyResets(s: AppState): AppState {
        val rBoss = Reset.lastWeekly(Reset.BOSS_DAY)
        val rGuild = Reset.lastWeekly(Reset.GUILD_DAY)
        val rMonth = Reset.lastMonthly()

        var toons = s.toons
        var changed = false

        if (rBoss > s.rBoss) {
            val weeklyIds = Bosses.weekly.map { it.id }.toSet()
            toons = toons.map { it.copy(done = it.done - weeklyIds) }
            changed = true
        }
        var guildFlag = s.guildFlag
        var guildWater = s.guildWater
        if (rGuild > s.rGuild) {
            guildFlag = false
            guildWater = false
            changed = true
        }
        if (rMonth > s.rMonth) {
            val monthlyIds = Bosses.monthly.map { it.id }.toSet()
            toons = toons.map { it.copy(done = it.done - monthlyIds) }
            changed = true
        }

        if (!changed && rBoss == s.rBoss && rGuild == s.rGuild && rMonth == s.rMonth) return s
        return s.copy(
            toons = toons,
            guildFlag = guildFlag,
            guildWater = guildWater,
            rBoss = rBoss, rGuild = rGuild, rMonth = rMonth
        )
    }

    // ── 저장 / 불러오기 ───────────────────────────────────────

    private fun persist() {
        prefs.edit().putString(KEY, encode(state).toString()).apply()
    }

    private fun load(): AppState {
        val raw = prefs.getString(KEY, null) ?: return AppState()
        return try {
            decode(JSONObject(raw))
        } catch (e: Exception) {
            AppState()
        }
    }

    private fun encode(s: AppState): JSONObject {
        val toons = JSONArray()
        s.toons.forEach { t ->
            val bosses = JSONObject()
            t.bosses.forEach { (k, v) -> bosses.put(k, v) }
            val done = JSONArray()
            t.done.forEach { done.put(it) }
            toons.put(
                JSONObject()
                    .put("id", t.id)
                    .put("name", t.name)
                    .put("ocid", t.ocid)
                    .put("world", t.world)
                    .put("job", t.job)
                    .put("level", t.level)
                    .put("bosses", bosses)
                    .put("done", done)
                    .put("party", JSONObject().also { pj -> t.party.forEach { (k, v) -> pj.put(k, v) } })
                    .put("syncedAt", t.syncedAt)
            )
        }
        return JSONObject()
            .put("v", 1)
            .put("toons", toons)
            .put("apiKey", s.apiKey)
            .put("guildFlag", s.guildFlag)
            .put("guildWater", s.guildWater)
            .put("autoSync", s.autoSync)
            .put("lastApiDate", s.lastApiDate)
            .put("priceOverrides", JSONObject().also { po -> s.priceOverrides.forEach { (k, v) -> po.put(k, v) } })
            .put("rBoss", s.rBoss)
            .put("rGuild", s.rGuild)
            .put("rMonth", s.rMonth)
    }

    private fun decode(o: JSONObject): AppState {
        val list = ArrayList<Toon>()
        var legacyFlag = false
        var legacyWater = false
        val arr = o.optJSONArray("toons") ?: JSONArray()
        for (i in 0 until arr.length()) {
            val t = arr.optJSONObject(i) ?: continue

            val bosses = LinkedHashMap<String, String>()
            t.optJSONObject("bosses")?.let { b ->
                val keys = b.keys()
                while (keys.hasNext()) {
                    val k = keys.next()
                    bosses[k] = b.optString(k, "")
                }
            }

            val done = HashSet<String>()
            t.optJSONArray("done")?.let { d ->
                for (j in 0 until d.length()) done.add(d.optString(j, ""))
            }

            val party = LinkedHashMap<String, Int>()
            t.optJSONObject("party")?.let { pj ->
                val keys = pj.keys()
                while (keys.hasNext()) {
                    val k = keys.next()
                    val v = pj.optInt(k, 1)
                    if (v > 1) party[k] = v
                }
            }

            list.add(
                Toon(
                    id = t.optString("id", System.nanoTime().toString()),
                    name = t.optString("name", "이름 없음"),
                    ocid = t.optString("ocid", ""),
                    world = t.optString("world", ""),
                    job = t.optString("job", ""),
                    level = t.optInt("level", 0),
                    bosses = bosses,
                    done = done,
                    party = party,
                    syncedAt = t.optLong("syncedAt", 0L)
                )
            )

            // 구버전(캐릭터별 길드 숙제) 값이 남아 있으면 계정 단위로 옮깁니다
            if (t.optBoolean("flag", false)) legacyFlag = true
            if (t.optBoolean("water", false)) legacyWater = true
        }
        return AppState(
            toons = list,
            apiKey = o.optString("apiKey", ""),
            guildFlag = o.optBoolean("guildFlag", legacyFlag),
            guildWater = o.optBoolean("guildWater", legacyWater),
            autoSync = o.optBoolean("autoSync", true),
            lastApiDate = o.optString("lastApiDate", ""),
            priceOverrides = LinkedHashMap<String, Long>().also { m ->
                o.optJSONObject("priceOverrides")?.let { po ->
                    val keys = po.keys()
                    while (keys.hasNext()) {
                        val k = keys.next()
                        m[k] = po.optLong(k, 0L)
                    }
                }
            },
            rBoss = o.optLong("rBoss", 0L),
            rGuild = o.optLong("rGuild", 0L),
            rMonth = o.optLong("rMonth", 0L)
        )
    }

    private companion object {
        const val KEY = "state"
    }
}
