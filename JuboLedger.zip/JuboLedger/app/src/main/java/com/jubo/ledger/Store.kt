package com.jubo.ledger

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject

/**
 * 앱 상태를 SharedPreferences 에 JSON 으로 저장합니다.
 * 외부 라이브러리 없이 org.json 만 사용합니다.
 */
class Store(context: Context) {

    private val prefs = context.applicationContext
        .getSharedPreferences("jubo_ledger", Context.MODE_PRIVATE)

    var state by mutableStateOf(applyResets(load()))
        private set

    init {
        persist()
    }

    fun update(block: (AppState) -> AppState) {
        val next = block(state)
        if (next !== state) {
            state = next
            persist()
        }
    }

    /** 초기화 시각이 지났으면 체크를 비웁니다. 1초마다 호출해도 안전합니다. */
    fun refreshResets() {
        val next = applyResets(state)
        if (next !== state) {
            state = next
            persist()
        }
    }

    fun updateToon(id: String, block: (Toon) -> Toon) = update { s ->
        s.copy(toons = s.toons.map { if (it.id == id) block(it) else it })
    }

    fun toggleAutoSync() = update { it.copy(autoSync = !it.autoSync) }

    /** 보스 체크를 켜고 끄면서 날짜별 기록도 같이 관리합니다 */
    fun toggleBoss(toonId: String, bossId: String) = update { s ->
        val t = s.toons.firstOrNull { it.id == toonId } ?: return@update s
        val tier = t.bosses[bossId] ?: return@update s
        val turningOn = !t.done.contains(bossId)

        val toons = s.toons.map {
            if (it.id != toonId) it
            else it.copy(done = if (turningOn) it.done + bossId else it.done - bossId)
        }

        val log = if (turningOn) {
            s.log + ClearEntry(
                date = Dates.todayKey(),
                toonId = toonId,
                toonName = t.name,
                bossId = bossId,
                tier = tier,
                party = t.partyOf(bossId),
                meso = t.myShare(bossId, tier, s.priceOverrides)
            )
        } else {
            // 가장 최근 같은 기록 하나만 지웁니다
            val idx = s.log.indexOfLast { it.toonId == toonId && it.bossId == bossId }
            if (idx >= 0) s.log.filterIndexed { i, _ -> i != idx } else s.log
        }

        s.copy(toons = toons, log = trimLog(log))
    }

    /** 스케줄러 동기화로 새로 확인된 클리어를 기록에 남깁니다 (같은 날 중복은 걸러냄) */
    fun appendClears(toonId: String, bossIds: Collection<String>) {
        if (bossIds.isEmpty()) return
        update { s ->
            val t = s.toons.firstOrNull { it.id == toonId } ?: return@update s
            val today = Dates.todayKey()
            var log = s.log
            bossIds.forEach { bossId ->
                val tier = t.bosses[bossId] ?: return@forEach
                val dup = log.any { it.date == today && it.toonId == toonId && it.bossId == bossId }
                if (!dup) {
                    log = log + ClearEntry(
                        date = today,
                        toonId = toonId,
                        toonName = t.name,
                        bossId = bossId,
                        tier = tier,
                        party = t.partyOf(bossId),
                        meso = t.myShare(bossId, tier, s.priceOverrides)
                    )
                }
            }
            s.copy(log = trimLog(log))
        }
    }

    /** 기록은 최근 400일치만 보관합니다 */
    private fun trimLog(log: List<ClearEntry>): List<ClearEntry> {
        if (log.size < 400) return log
        val cutoff = Dates.today().minusDays(400)
        return log.filter { e -> Dates.parse(e.date)?.isBefore(cutoff) != true }
    }

    /** 보스별 파티 인원 지정 (1이면 솔로) */
    fun setParty(toonId: String, bossId: String, people: Int) = updateToon(toonId) { t ->
        val v = people.coerceAtLeast(1)
        t.copy(party = if (v <= 1) t.party - bossId else t.party + (bossId to v))
    }

    /** 결정석 가격 직접 수정 (만 메소). 0 이하면 되돌립니다. */
    fun setPrice(bossId: String, tier: String, manMeso: Long) = update { s ->
        val k = priceKey(bossId, tier)
        s.copy(priceOverrides = if (manMeso <= 0L) s.priceOverrides - k else s.priceOverrides + (k to manMeso))
    }

    fun toggleFlag() = update { it.copy(guildFlag = !it.guildFlag) }
    fun toggleWater() = update { it.copy(guildWater = !it.guildWater) }

    // ── 초기화 ────────────────────────────────────────────────

    private fun applyResets(s: AppState): AppState {
        val rBoss = Reset.lastWeekly(Reset.BOSS_DAY)
        val rGuild = Reset.lastWeekly(Reset.GUILD_DAY)
        val rMonth = Reset.lastMonthly()

        var toons = s.toons
        var changed = false

        if (rBoss > s.rBoss) {
            val weeklyIds = Bosses.weekly.map { it.id }.toSet()
            toons = toons.map { it.copy(done = it.done - weeklyIds) }
            changed = true
        }
        var guildFlag = s.guildFlag
        var guildWater = s.guildWater
        if (rGuild > s.rGuild) {
            guildFlag = false
            guildWater = false
            changed = true
        }
        if (rMonth > s.rMonth) {
            val monthlyIds = Bosses.monthly.map { it.id }.toSet()
            toons = toons.map { it.copy(done = it.done - monthlyIds) }
            changed = true
        }

        if (!changed && rBoss == s.rBoss && rGuild == s.rGuild && rMonth == s.rMonth) return s
        return s.copy(
            toons = toons,
            guildFlag = guildFlag,
            guildWater = guildWater,
            rBoss = rBoss, rGuild = rGuild, rMonth = rMonth
        )
    }

    // ── 저장 / 불러오기 ───────────────────────────────────────

    private fun persist() {
        prefs.edit().putString(KEY, encode(state).toString()).apply()
    }

    private fun load(): AppState {
        val raw = prefs.getString(KEY, null) ?: return AppState()
        return try {
            decode(JSONObject(raw))
        } catch (e: Exception) {
            AppState()
        }
    }

    private fun encode(s: AppState): JSONObject {
        val toons = JSONArray()
        s.toons.forEach { t ->
            val bosses = JSONObject()
            t.bosses.forEach { (k, v) -> bosses.put(k, v) }
            val done = JSONArray()
            t.done.forEach { done.put(it) }
            toons.put(
                JSONObject()
                    .put("id", t.id)
                    .put("name", t.name)
                    .put("ocid", t.ocid)
                    .put("world", t.world)
                    .put("job", t.job)
                    .put("level", t.level)
                    .put("bosses", bosses)
                    .put("done", done)
                    .put("party", JSONObject().also { pj -> t.party.forEach { (k, v) -> pj.put(k, v) } })
                    .put("syncedAt", t.syncedAt)
            )
        }
        return JSONObject()
            .put("v", 1)
            .put("toons", toons)
            .put("apiKey", s.apiKey)
            .put("guildFlag", s.guildFlag)
            .put("guildWater", s.guildWater)
            .put("autoSync", s.autoSync)
            .put("lastApiDate", s.lastApiDate)
            .put("priceOverrides", JSONObject().also { po -> s.priceOverrides.forEach { (k, v) -> po.put(k, v) } })
            .put("log", JSONArray().also { arr ->
                s.log.forEach { e ->
                    arr.put(
                        JSONObject()
                            .put("d", e.date).put("ti", e.toonId).put("tn", e.toonName)
                            .put("b", e.bossId).put("df", e.tier).put("p", e.party).put("m", e.meso)
                    )
                }
            })
            .put("rBoss", s.rBoss)
            .put("rGuild", s.rGuild)
            .put("rMonth", s.rMonth)
    }

    private fun decode(o: JSONObject): AppState {
        val list = ArrayList<Toon>()
        var legacyFlag = false
        var legacyWater = false
        val arr = o.optJSONArray("toons") ?: JSONArray()
        for (i in 0 until arr.length()) {
            val t = arr.optJSONObject(i) ?: continue

            val bosses = LinkedHashMap<String, String>()
            t.optJSONObject("bosses")?.let { b ->
                val keys = b.keys()
                while (keys.hasNext()) {
                    val k = keys.next()
                    bosses[k] = b.optString(k, "")
                }
            }

            val done = HashSet<String>()
            t.optJSONArray("done")?.let { d ->
                for (j in 0 until d.length()) done.add(d.optString(j, ""))
            }

            val party = LinkedHashMap<String, Int>()
            t.optJSONObject("party")?.let { pj ->
                val keys = pj.keys()
                while (keys.hasNext()) {
                    val k = keys.next()
                    val v = pj.optInt(k, 1)
                    if (v > 1) party[k] = v
                }
            }

            list.add(
                Toon(
                    id = t.optString("id", System.nanoTime().toString()),
                    name = t.optString("name", "이름 없음"),
                    ocid = t.optString("ocid", ""),
                    world = t.optString("world", ""),
                    job = t.optString("job", ""),
                    level = t.optInt("level", 0),
                    bosses = bosses,
                    done = done,
                    party = party,
                    syncedAt = t.optLong("syncedAt", 0L)
                )
            )

            // 구버전(캐릭터별 길드 숙제) 값이 남아 있으면 계정 단위로 옮깁니다
            if (t.optBoolean("flag", false)) legacyFlag = true
            if (t.optBoolean("water", false)) legacyWater = true
        }
        return AppState(
            toons = list,
            apiKey = o.optString("apiKey", ""),
            guildFlag = o.optBoolean("guildFlag", legacyFlag),
            guildWater = o.optBoolean("guildWater", legacyWater),
            autoSync = o.optBoolean("autoSync", true),
            lastApiDate = o.optString("lastApiDate", ""),
            priceOverrides = LinkedHashMap<String, Long>().also { m ->
                o.optJSONObject("priceOverrides")?.let { po ->
                    val keys = po.keys()
                    while (keys.hasNext()) {
                        val k = keys.next()
                        m[k] = po.optLong(k, 0L)
                    }
                }
            },
            log = ArrayList<ClearEntry>().also { out ->
                o.optJSONArray("log")?.let { arr ->
                    for (i in 0 until arr.length()) {
                        val e = arr.optJSONObject(i) ?: continue
                        out.add(
                            ClearEntry(
                                date = e.optString("d", ""),
                                toonId = e.optString("ti", ""),
                                toonName = e.optString("tn", ""),
                                bossId = e.optString("b", ""),
                                tier = e.optString("df", ""),
                                party = e.optInt("p", 1),
                                meso = e.optLong("m", 0L)
                            )
                        )
                    }
                }
            },
            rBoss = o.optLong("rBoss", 0L),
            rGuild = o.optLong("rGuild", 0L),
            rMonth = o.optLong("rMonth", 0L)
        )
    }

    private companion object {
        const val KEY = "state"
    }
}
